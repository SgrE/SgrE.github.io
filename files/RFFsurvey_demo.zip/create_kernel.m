function K = create_kernel(x1,x2,k_type,k_par,a)

switch k_type
    case 'gauss'
        %K	= exp(-dist(x1,x2)./(k_par^2));  %%%%%
        K	= exp(-distf(x1,x2)*k_par);  %%%%%
    case 'delta-gauss'
        K	= exp(-distf(x1,x2)*k_par) - exp(-distf(x1,x2)*a); 
    case 'linear'
        K = x1*x2';
    case 'poly'
        K = (x1*x2' + a).^k_par;
    case 'log'
        K = -log(1+distf(x1,x2).^(k_par/2));
    case 'power'
        K = - distf(x1,x2).^k_par/2;
    case 'ntk' % on sphere
        temp = distf(x1,x2);
        %temp(temp>4)=0;
        u = 1 - 1/2*temp;
        k0 = 1 - 1/pi*acos(u);
        k1 = 1/pi*( u.*(pi - acos(u)) + 1 - u );
        K = u.*k0 + k1;
        K = real(K);
    case 'ntksp' % on sphere
        temp = distf(x1,x2);
        temp(temp>4)=0;
        u = 1/2*temp - 1;
        temp1 = real(temp.^(1/2));
        K = 1/pi*(-2*u).*acos(u)+temp1/2/pi.*sqrt(4-temp);
        K = real(K);
    case 'polysp'
        %a = 4;
        temp = distf(x1,x2);
        temp(temp>=4) = a^2;
        
        K = ( 1- temp/a^2).^k_par;
    case 'arccos1sp'
        %a = 4;
        temp = distf(x1,x2);
        %temp(temp>=4) = a^2;
        K = sqrt(temp)/pi/2.*sqrt(4-temp);
    case 'tl1'
        a = max(0,distf(x1,x2)); % avoid numerical 
        K = max(0.7*size(x1,2)-a.^(1/2),0);
%         K = zeros(size(x1,1),size(x2,1));
%         for i = 1:size(x2,1)
%             K(:,i) = max(0.7*size(x1,2)-sum((abs(bsxfun(@minus,x1,x2(i,:))).^1),2),0)/(0.7*size(x1,2)); %normlized
%         end

end

% sA = (sum(A.^2, 2));
% sB = (sum(B.^2, 2));
% K2 = exp(bsxfun(@minus,bsxfun(@minus,2*A*B', sA), sB')/beta);
% function distance = distf(X,Y)
% nx	= size(X,1);
% ny	= size(Y,1);
% distance=sum((X.^2),2)*ones(1,ny) +...
%     ones(nx,1)*sum((Y.^2),2)' - 2*(X*Y');