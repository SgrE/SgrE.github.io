function [X_train,X_test] = dataprocessing(title,X_train,X_test)

switch title
    case {'cod_rna','EEG','wine-quality'}
        X_train = mapstd(X_train); X_test = mapstd(X_test);
    case {'letter','wilt'}
        X_min = repmat(min( X_train ), [size(X_train, 1),1]); X_max = repmat(max( X_train ), [size(X_train, 1),1]); X_train = (X_train - X_min)./(X_max - X_min);
        X_min = repmat(min( X_test ), [size(X_test, 1),1]); X_max = repmat(max( X_test ), [size(X_test, 1),1]); X_test = (X_test - X_min)./(X_max - X_min);
        
end