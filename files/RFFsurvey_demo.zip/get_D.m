function D = get_D(d,n)

%  when using simplex method to generate points, we add also reflected ones,
%     so the overall number of points created is 2 * (n+1) + 1, where 1 comes
%     from the weight of function at zero. Since we add f(0) directly to the
%     integral, we don't need to account for it in D here.
    
D = floor(n * (2 * (d+1)));
%D = n;