function dataf = dataload(title)

dataf = [];
switch title
    case {'ijcnn1','w4a','gisette_scale','cod_rna'}
        [Y_train,X_train] = libsvmread(['.\data\' title '.train']);
        [Y_test,X_test] = libsvmread(['.\data\' title '.t']);
        dataf.Y_train = Y_train; dataf.Y_test = Y_test;
        dataf.X_train = X_train; dataf.X_test = X_test;
        dataf.flagtest = 1;
    case {'letter','wilt'}
        load([ '.\data\' title '.mat'])
        dataf.Y_train = Y_train; dataf.Y_test = Y_test;
        dataf.X_train = X_train; dataf.X_test = X_test;
        dataf.flagtest = 1;
    case {'EEG','spambase','magic04','wine-quality','mnist8m-sub'}
        load([ '.\data\' title '.mat'])
        dataf.X = X; dataf.Y = Y;
        dataf.flagtest = 0;   
    case {'covtype','skin','mushrooms'}
        [Y,X] = libsvmread(['E:\UCI\' title]);
        Y(Y==2)=-1; 
        dataf.X = X; dataf.Y = Y;
        dataf.flagtest = 0;
    case 'a8a'
        [Y_train,X_train] = libsvmread('.\data\a8a'); %X_train = X_train(:,1:end-1);
        [Y_test,X_test] = libsvmread('.\data\a8a.t'); 
        X_test = [X_test,zeros(length(Y_test),1)];
        
        dataf.Y_train = Y_train; dataf.Y_test = Y_test;
        dataf.X_train = X_train; dataf.X_test = X_test;
        dataf.flagtest = 1;
    case 'mnist'
        load([ '.\data\' title '.mat'])
        dataf.Y_train = Xlabel; dataf.Y_test = Xtestlabel;
        dataf.X_train = Xdata; dataf.X_test = Xtestdata;
        dataf.flagtest = 1;
    case 'cifar10'
        load('.\data\cifar10_feature.mat'); 
        load('.\data\cifar10_label.mat');
        dataf.X_train = train_feature; dataf.X_test = test_feature; dataf.Y_train = train_label'+1; dataf.Y_test = test_label'+1;
end