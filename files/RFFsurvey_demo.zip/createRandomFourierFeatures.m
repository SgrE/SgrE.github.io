function Z = createRandomFourierFeatures(D, W, b, X,typeker)
%creates (Gaussian) random features
% Inputs:
% D the number of features to make
% W, b the parameters for those features (d x D and 1 x D)
% X the datapoints to use to generate those features (d x N)
% typerker: kernel type

%Ouputs:
%Z the transformed feature matrix

if strcmp(typeker,'gauss')
    Z = sqrt(1/D)*[cos(bsxfun(@plus,conj(W')*X, b'));sin(bsxfun(@plus,conj(W')*X, b'))];
elseif  strcmp(typeker,'arccos1')
    %Z = sqrt(1/D)*[max(bsxfun(@plus,conj(W')*X, b'),0);max(bsxfun(@plus,conj(W')*X, b'),0)];
    Z = sqrt(2/D)*[max(bsxfun(@plus,conj(W')*X, b'),0)];
elseif  strcmp(typeker,'arccos0')
    % Z = sqrt(1/D)*[max(sign(bsxfun(@plus,conj(W')*X, b')),0);max(sign(bsxfun(@plus,conj(W')*X, b')),0)];
    Z = sqrt(2/D)*[heaviside(bsxfun(@plus,conj(W')*X, b'))];
end
end