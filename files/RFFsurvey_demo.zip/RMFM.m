function DATA_SKETCH = RMFM(DATA, K, C, CS_COL)

[N, D] = size(DATA);

% Fix a value p > 1
P = 2;

% Generate Maclaurin coefficients
COEF = zeros(1, K + 1);
for i = 1 : K + 1
    COEF(i) = nchoosek(K, i - 1) * C^(K + 1 - i);
end

% Generate random features
DATA_SKETCH = zeros(N, CS_COL);

% Generate a non negative integer N with prob. P(N = n) = 1/p^(n+1)
R = floor(log2(1 ./ rand(1, CS_COL)));

for i = 1 : CS_COL
    
    % Choosing a random degree to approximate
    iRan = R(i);
    
    if iRan > K
        continue;
    end
    
    % Constant coefficients of polynomial
    const = sqrt(COEF(iRan + 1)) * sqrt(P^(iRan + 1)); % sqrt(a_N * p^(N+1))
    
    if iRan > 0 % Only need a_1, a_2, ...
        
        bitHASH = double(randi(2, iRan, D) - 1.5 ) * 2;  % Matrix of R x D
        temp    = DATA * bitHASH';
        
        DATA_SKETCH(:, i) = const .* prod(temp, 2);
        
    else
        
        DATA_SKETCH(:, i) = const .* ones(N, 1);
        
    end
end

% Scaling
DATA_SKETCH = DATA_SKETCH / sqrt(CS_COL);
end