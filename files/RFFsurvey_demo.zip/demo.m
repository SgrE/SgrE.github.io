%% Demo-Random features survey

close all
%clear all
addpath('D:\liblinear-2.20\matlab\');
addpath('.\CrossValidation\')
addpath('.\SSR\')
rand('state',0);    randn('state',0);
savepath  = ['.\Results\'];

typeRF = 'rff'; % rff orf sorf rom fastfood qmc ssf gq le-rff ssr// rff rom qmc ssf ssr // ts trp rm
title = 'letter'; % ijcnn1,EEG, cod_rna, covtype, magic04, letter, skin, a8a, mushrooms, spambase, wilt, wine-quality
kernel_type = 'gauss'; % gauss arccos0 arccos1 poly
polyparam.order = 2; polyparam.c = 1; % polynomial kernel parameter


typeC = 'lr'; % ;lr liblinear
typeCorR = 'classification';
flagCV =0; % cross validation for classifier
n_sample = 1000; % subsample for kernel approximation evaluation
setd = [2,4,8]; % #random features {setd}*d
Iternum =10; %iteration number
res = zeros(length(setd),Iternum);
time_acc = zeros(length(setd),Iternum);
approxi_res = zeros(length(setd),Iternum);

for jjj = 1:length(setd)
    kkm = setd(jjj);
    
    dataf = dataload(title);
    if dataf.flagtest == 1
        Y_train = dataf.Y_train; Y_test = dataf.Y_test;
        X_train = dataf.X_train; X_test = dataf.X_test;
    else
        X = dataf.X; Y = dataf.Y;
    end
    
    for sss = 1:Iternum
        
        sss
        duration = 0;
        if sss == 1
            if dataf.flagtest == 0
                rate = 1/2;
                Training_num = round(length(Y)*rate);
                [~, index] = sort(rand( length(Y), 1));
                X_train = X( index( end - Training_num+1 : end), : );
                Y_train = Y( index( end - Training_num+1: end));
                X_test = X( index( 1 : end - Training_num), : );
                Y_test = Y( index( 1 : end - Training_num));
            end
            
            switch title
                case {'cod_rna','EEG','wine-quality'}
                    X_train = mapstd(X_train); X_test = mapstd(X_test);
                case {'letter','wilt','magic04','spambase'}
                    X_min = repmat(min( X_train ), [size(X_train, 1),1]); X_max = repmat(max( X_train ), [size(X_train, 1),1]); X_train = (X_train - X_min)./(X_max - X_min);
                    X_min = repmat(min( X_test ), [size(X_test, 1),1]); X_max = repmat(max( X_test ), [size(X_test, 1),1]); X_test = (X_test - X_min)./(X_max - X_min);
                case 'mnist'
                    X_train = X_train/255; X_test = X_test/255;
            end
            X_train(isnan(X_train)==1) = 0; X_test(isnan(X_test)==1) = 0; 
        end
        
        n=size(X_train,1);
        d = size(X_train,2);
        m = size(X_test,1);
        
        
        %------Gaussian kernel width sigma cross validation
        sigma = 1; %after cross validation: mnist: sigma = 0.1; cifar10: sigma = 100;
        %{
        if strcmp(typeker,'gauss') & sss == 1
            L_fold = 5;
            [~, index] = sort(rand( length(Y_train), 1));
            X_sub = X_train(index(1:n_sample),:);
            Y_sub = Y_train(index(1:n_sample));
            [bestc, bestg, ~] = automaticParameterSelectionsigma(Y_sub, X_sub, L_fold);
            sigma = bestg;
        end
        %}
        
        D =kkm*d;% #random features
        %D = 2000;
        if strcmp(kernel_type,'gauss')
            b = rand(1,D)*2*pi;
        else
            b = zeros(1,D);
        end
        tic;
        
        if strcmp(typeRF,'ssf') % SSF ICML2017
            Tn=5;
            if mod(d,2) ~= 0
                d = d + 1;
                D = kkm*d;
                X_train = [X_train,zeros(n,1)];
                X_test = [X_test,zeros(m,1)];
                [base,bestD] = LogEnergyOP_Demo(d/2, ceil(D/2),Tn);
                b = rand(1,D)*2*pi;
            else
                [base,bestD] = LogEnergyOP_Demo(d/2, ceil(D/2),Tn);
            end
            [Z_train, Z_test] = SSFmappingnew(D,base,d,b,X_train,X_test, sigma,kernel_type);
        elseif strcmp(typeRF,'ssr') % SSR NeurIPS2018
            Dk = max(1,floor(kkm/2));
            Xdata = [X_train;X_test];
            
            if strcmp(kernel_type,'gauss')
                [M, w,Ddimen] = butt_quad_mapping(Xdata',Dk, 1);
                M = M/sigma;
                weights1 = w;
                temp_weights = [weights1';weights1'];
                
                Mapping = bsxfun(@times,temp_weights,[cos(M);sin(M)])/sqrt(Ddimen);
                
            elseif  strcmp(kernel_type,'arccos1')
                [M, w,Ddimen] = butt_quad_mapping(Xdata',Dk, 0);
                Mapping = sqrt(2)*bsxfun(@times,w',max(M,0))/sqrt(Ddimen);
            elseif  strcmp(kernel_type,'arccos0')
                [M, w,Ddimen] = butt_quad_mapping(Xdata',Dk, 0);
                Mapping = sqrt(2)*bsxfun(@times,w',max(sign(M),0))/sqrt(Ddimen);
            end
            Z_train = Mapping(:,1:size(X_train,1));
            Z_test = Mapping(:,size(X_train,1)+1:end);

        elseif strcmp(typeRF,'ts') || strcmp(typeRF,'trp') || strcmp(typeRF,'rm') % polynomial kernel
            XX =[X_train; X_test]; DATA = full(XX); [N,~]=size(DATA);
            temp    = repmat(polyparam.c, N, 1);
            DATA    = [DATA temp];
            d = d+1;
            if strcmp(typeRF,'trp')
                tCS_DATA = OUR_SKETCH(DATA, polyparam.order,D); % TRP NIPS2019
            elseif strcmp(typeRF,'ts')
                tCS_DATA    = FFT_CountSketch_k_Naive(DATA, polyparam.order,D); %TS KDD2013
            elseif strcmp(typeRF,'rm')
                tCS_DATA    = RMFM(DATA(:, 1 : d - 1), polyparam.order, polyparam.c, D); %RS AISTATS2012
            end
            a1 = tCS_DATA(1:n,:); a2 =tCS_DATA(n+1:end,:);
            Z_train = a1'; Z_test = a2';
        else
            W = RandomFeatures(D, d,sigma,typeRF);
            switch typeRF
                case 'le-rff' %
                    [Z_train,Z_test]= leverageRFFnew(D, W, b, X_train',X_test');
                otherwise
                    Z_train = createRandomFourierFeatures(D, W, b, X_train',kernel_type);
                    Z_test = createRandomFourierFeatures(D, W, b, X_test',kernel_type);
            end
        end
        duration = duration + toc;
         switch typeCorR
             case 'classification'
                 [accTrain, accTest] = RFclassification(Z_train,Z_test,Y_train,Y_test,typeC,flagCV);
             case 'regression'
                 [accTrain, accTest] = RFregression(Z_train,Z_test,Y_train,Y_test,typeC,flagCV);
         end
        res(jjj,sss) = accTest;
        time_acc(jjj,sss) = duration;
        
        
        %% kernel approximation
        
        [temp, index] = sort(rand( length(Y_train), 1));
        X_sub = X_train(index(1:n_sample),:);
        Z_sub = Z_train(:,index(1:n_sample));
        
        if strcmp(kernel_type,'gauss')
            K_sub = create_kernel(X_sub,X_sub,'gauss',1/(2*sigma^2));
        elseif strcmp(kernel_type,'poly')
            K_sub = create_kernel(X_sub,X_sub,'poly',polyparam.order, polyparam.c);
        elseif strcmp(kernel_type,'arccos0')
            a1 = X_sub';
            aq1 = sqrt(sum(a1.^2))+eps;
            aq2 = aq1'*aq1;
            theta1 = real(acos(X_sub*X_sub'./ aq2));
            thm = pi-theta1;
            K_sub = 1/pi*thm;
        elseif strcmp(kernel_type,'arccos1')
            %X_sub = full(X_sub);
            a1 = X_sub';
            aq1 = sqrt(sum(a1.^2))+eps;
            aq2 = aq1'*aq1;
            theta1 = real(acos(X_sub*X_sub'./ aq2));
            thm = sin(theta1)+(pi-theta1).*cos(theta1);
            K_sub = 1/pi*aq2.*thm; %K_sub = full(K_sub);
        end
        
        ZK = (conj(Z_sub')*Z_sub);
        if strcmp(typeRF,'ssr')  & strcmp(kernel_type,'gauss')
            ZK = ZK + 1 - ZK(1,1);%mean(w.^2);
        end
        error = norm(K_sub - ZK,'fro')/norm(K_sub,'fro');
        approxi_res(jjj,sss) = error;
        %save(['.\Features\' typeRF '\' num2str(sss) '_' num2str(ks),'d.mat'], 'Z_train','Z_test','W');
        clear Z_train Z_test
        
    end
    clear X_train X_test Y_train Y_test
    res_trials = res(jjj,:);
    time_trials = time_acc(jjj,:);
    app_trials = approxi_res(jjj,:);
    %save([savepath title '_' typeRF '_' typeC '_' num2str(kkm) 'd','.mat'], 'res_trials','time_trials','app_trials');
end

for j = 1:length(setd)
    kkm = setd(j);
    fprintf('%.2f��%.2f (%.2f��%.2f) (%.6f��%.6f)\n',mean(res(j,:)),std(res(j,:)),mean(time_acc(j,:)),std(time_acc(j,:)),mean(approxi_res(j,:)),std((approxi_res(j,:))));
end