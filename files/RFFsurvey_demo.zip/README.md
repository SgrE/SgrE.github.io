# Random Features Survey
This repository maintains the code comparing the performance of representative random features based algorithms. It generates the experiment results for the paper [Random Features for Kernel Approximation: A Survey on Algorithms, Theory, and Beyond](https://arxiv.org/abs/2004.11154).

## Data Sets
One can directly run the main function `demo.m` on the `letter` dataset for evaluation. More datasets can be downloaded from the links listed in the paper, and then added into the path '.\data\'. 

## Parameters
The parameters include:
title: filename of the dataset
kernel_type: Gaussian kernels ('gauss'), arc-cosine kernels ('arccos0', 'arccos1'), polynomial kernels ('poly')
typeRF: compared methods including `rff` `orf` `sorf` `rom` `fastfood` `qmc` `ssf` `gq` `le-rff` `ssr` for Gaussian kernels; `rff` `rom` `qmc` `ssf` `ssr` for arc-cosine kernels; `ts` `trp` `rm` for polynomial kernels.
typeC: the classifier type including `lr` for linear regression and 'liblinear' for linear SVM which requires the liblinear library.
