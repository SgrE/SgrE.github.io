function M = singleM(q,d)
H = zeros(d); H(1,1)=1;
if d <1
    f = 0;
else
    f = log2(d);
end
for j = 0:f-1
    p = 2^j;
    H(1:p,p+1:2*p) = H(1:p, 1:p);
    H(p+1:2*p,1:p) = H(1:p,1:p);
    H(p+1:2*p, p+1:2*p) = -H(1:p,1:p);
end
S = H/sqrt(d);
            
Ds = 2*(rand(1,d)<0.5) - 1; 
D = diag(Ds);

M = S*D;
for j = 1:q-1
    Ds = 2*(rand(1,d)<0.5) - 1;
    D = diag(Ds);
    M = M*(S*D);
end