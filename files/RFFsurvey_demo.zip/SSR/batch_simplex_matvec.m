function r = batch_simplex_matvec(x)
%x: d*n data matrix
    nobj = size(x,2);
    d = size(x,1);
    mp = d + 1;
    r = zeros(d+1, nobj);
    rv = zeros(1,d);
    s = zeros(1,nobj);
    for i=0:d-1
        rv(i+1) = sqrt(mp / ((d-i) * d * (d-i+1)));
        rvo = rv(i+1) * x(i+1,:);
        r(i+1,:) = s + rvo*(d-i);
        s = s - rvo;
    end
    r(d+1,:) = s;