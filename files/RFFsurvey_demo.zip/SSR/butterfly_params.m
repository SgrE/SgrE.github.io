function [cosf,sinf,perm] = butterfly_params(n, k)
    h = ceil(k);
    loga = log2(n);
    next_power = 2^ceil(loga);
    cosf = zeros(h, next_power-1);
    sinf = zeros(h, next_power-1);
    perm = zeros(h, n);
    for i=0:h-1
        [c, s] = cos_sin(n);
        cosf(i+1,:) = c;
        sinf(i+1,:) = s;
        p = 1:1:n;
        p= p(randperm(length(p)));
        perm(i+1,:) = p;
    end