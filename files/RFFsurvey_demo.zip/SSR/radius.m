function r = radius(d, n)
    rm = d + 2;
    D = floor(get_D(d, n) / 2);
    r = sqrt(2 * gamrnd(rm/2,1,[1,D]));