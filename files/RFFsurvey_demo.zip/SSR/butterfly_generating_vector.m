function u = butterfly_generating_vector(n)
% Generates a vector `u` used to construct random butterfly orthogonal matrices.
%n: size of generating vector, n = N + 1 to construct random butterfly orthogonal matrix of size N x N.
% Returns:
% u: generating vector used to calculate angles for random butterfly orthogonal matrices.

    l = floor(n/2) - 1;
    r = rand(1,n-1);
   %r= [0.98665705, 0.69816809, 0.32969309, 0.05006895, 0.77289173,0.92128365, 0.11422498, 0.56809026, 0.58707295];
   %r=[1.873378697645549096e-01,2.775817681385864821e-01,7.602336419697656167e-01,1.072794977724713661e-01,1.254574292712610228e-01,7.506119119855543254e-01];

    u = zeros(1,n);

    for i=0:l-1
        m = n - 2*i;
        s = sin(2 * pi * r(m-1));
        c = cos(2 * pi * r(m-1));
        if i == 0
            p = 1;
        else
            temp1 = 1:i;
            pos = n - 2*temp1 - 1;
            ds = 1./(pos + 1);
            p = prod(r(pos+1).^ds);
        end
%         temp1 = 1:i+1;
%         pos = n - 2*temp1 - 1;
%         ds = 1./(pos + 1);
%         p = prod(r(pos).^ds);

        u(m) = sqrt(1. - r(m-2)^(2./(m-3))) * p * s;
        u(m-1) = sqrt(1. - r(m-2)^(2./(m-3))) * p * c;
    end

    s = sin(2*pi * r(1));
    c = cos(2 *pi*r(1));
    temp1 = 1:l;
    pos = n - 2*temp1 - 1;
    ds = 1./(pos + 1);
    p = prod(r(pos+1).^ds);
    
    if mod(n,2) == 0
        u(1) = c * p;
        u(2) = s * p;
    else
        u(3) = (2 * r(2) - 1) * p;
        u(2) = 2 * sqrt(r(2) * (1 - r(2))) * p * s;
        u(1) = 2 * sqrt(r(2) * (1 - r(2))) * p * c;
    end