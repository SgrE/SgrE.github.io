function x = batch_butterfly_matvec(x, cosfv, sinfv, p)
NQ = 3;
    d = size(x,1);
    h = ceil(log2(d));

    for i = 1:NQ
        for n = 1:h
            x = batch_factor_matvec(x, n, cosfv, sinfv);
        end
        x = x(p,:);
    end