function [Mx, w,D] = butt_quad_mapping(x, n, evenflag,r, b_params)
%               |V^T Q_0^T x|
%     Mx = \rho |    ...    |
%               |V^T Q_n^T x|
%     Args:
%     =====
%     x: the data vector of dimension d.
%     n: the parameter defining the new number of features.
%
%     Returns:
%     ========
%     Mx: the mapping Mx.
%     w: the weights.

nobj = size(x,2);
d = size(x,1);
D = get_D(d, n);
%D = n;
Mx = zeros(D, nobj);

if evenflag == 1
    t = ceil(2*n);
else
    t = ceil(n);
end

r = radius(d, t);
[cosf,sinf,perm] = butterfly_params(d, t);


w = zeros(1,D);
%{
    if n < 1
        if n > 0.5
            d0 = ceil(get_D(d, 1)/2);
            rr = ones(d0, 1);
            
            rr(:,1) = r(1:d0);
            Mx(1:d,:) = rr * get_batch_mx(x, cosf(1,:), sinf(1,:), perm(1,:));
            w(:) = sqrt(d) / rr(:, 1);
            if evenflag == 1
                dd = d0;
                d0 = size(r,1);
                rr = ones(d0-dd, 1);
                rr(:,1) = r(d0+1:end);
                temM = get_batch_mx(x, cosf(2,:), sinf(2,:),permf(2,:));
                Mx(d+2:end, :) = rr * temM(D-d,:);
                w(d+2:end) = sqrt(d) / rr(:,1);
            else
                Mx(d+2:end,:) = -Mx(1:D-d-1, :);
            end
        else
            temM = get_batch_mx(x, cosf(1,:), sinf(1,:), perm(1,:));
            aa = repmat(r',1,size(temM,2));
            Mx = aa.* temM(1:D, :);
            w = sqrt(d)*1./r;
        end
    end
%}
if evenflag == 1 % gaussian kernel
    dd = 0;
    for i=0:t-2
        d0 = floor(get_D(d, i+1) / 2);
        rr = ones(d0-dd, 1);
        rr(:, 1) = r(dd+1:d0);
        w(i*(d+1)+1:(i+1)*(d+1)) = sqrt(d)*1./ rr(:,1);
        temM = get_batch_mx(x, cosf(i+1,:), sinf(i+1,:), perm(i+1,:));
        aa = repmat(rr,1,size(temM,2));
        Mx(i*(d+1)+1:(i+1)*(d+1), :) = aa.* temM;
        dd = d0;
    end
    
    i = t - 1;
    d0 = floor(get_D(d, i+1) / 2);
    rr = ones(d0-dd, 1);
    rr(:, 1) = r(dd+1:d0);
    temM = get_batch_mx(x, cosf(i+1,:), sinf(i+1,:), perm(i+1,:));
    aa = repmat(rr,1,size(temM,2));
    Mx(i*(d+1)+1:end, :) = aa.* temM;
    w(i*(d+1)+1:end) = sqrt(d) *1./ rr(:, 1);
    
else % arccos kernel
    dd = 0;
    for i=0:t-1
        d0 = floor(get_D(d,(i+1)) / 2);
        rr = ones(d0-dd, 1);
        rr(:, 1) = r(dd+1:d0);
        w(i*(d+1)+1:(i+1)*(d+1)) = sqrt(d)*1./ rr(:,1);
        temM = get_batch_mx(x, cosf(i+1,:), sinf(i+1,:), perm(i+1,:));
        aa = repmat(rr,1,size(temM,2));
        Mx(i*(d+1)+1:(i+1)*(d+1), :) = aa.* temM;
        dd = d0;
        div = t * (d+1);
        Mx(div+1:end, :) = -Mx(1:D-div, :);
        w(div+1:end) = w(1:D-div);
    end
end