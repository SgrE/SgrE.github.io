function [cosf,sinf] = cos_sin(N)
    c = log2(N);
    f = ceil(c);
    n = ceil(2^f);
    u = butterfly_generating_vector(n);
    thetas = butterfly_angles(u);
    if c ~= f
        thetas = [thetas(1:N-1), zeros(1,(n - N))];
    end
    cosf = cos(thetas);
    sinf = sin(thetas);