function [ZX,ZXT] = SSFmappingnew(D,base,d,b, X,XT, sigma,typeker)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%b = zeros(1,D);
X =  X/sigma;
D0 = sign(randn(d,1));
X =bsxfun(@times,X',D0);
XT = bsxfun(@times,XT',D0);
[ZXn] = SSF( X,D,base );
[ZXT] = SSF( XT,D,base );
if strcmp(typeker,'gauss')
    Norm1 = sqrt(icdf('chi2',1/2,d) );  % For Gaussian kernel
    ZX = Norm1 *ZXn;
    ZX = sqrt(1/D)*[cos(bsxfun(@plus,ZX, b'));sin(bsxfun(@plus,ZX, b'))];
    %ZX = sqrt(1/D)*[cos(ZX);sin(ZX)];
    ZXT = Norm1 *ZXT;
    %ZXT = sqrt(1/D) *[cos(ZXT);sin(ZXT)];
    ZXT = sqrt(1/D)*[cos(bsxfun(@plus,ZXT, b'));sin(bsxfun(@plus,ZXT, b'))];
elseif strcmp(typeker,'arccos1')
    Norm2= sqrt(d);                     % For cosKerel and angelKernel from the closed form
    ZX = Norm2 * ZXn;
    %Y= [(ZX>0);(ZX<=0)] * sqrt(1/Nn);
    ZX = sqrt(1/D)*[max(bsxfun(@plus,ZX, b'),0);max(bsxfun(@plus,ZX, b'),0)];
    ZXT = Norm2 *ZXT;
    %ZXT = sqrt(1/D) *[cos(ZXT);sin(ZXT)];
    ZXT = sqrt(1/D)*[max(bsxfun(@plus,ZXT, b'),0);max(bsxfun(@plus,ZXT, b'),0)];
elseif strcmp(typeker,'arccos0')
    Norm2= sqrt(d);                     % For cosKerel and angelKernel from the closed form
    ZX = Norm2 * ZXn;
    ZX = sqrt(1/D)*[max(sign(bsxfun(@plus,ZX, b')),0);max(sign(bsxfun(@plus,ZX, b')),0)];
    ZXT = Norm2 *ZXT;
    %ZXT = sqrt(1/D) *[cos(ZXT);sin(ZXT)];
    ZXT = sqrt(1/D)*[max(sign(bsxfun(@plus,ZXT, b')),0);max(sign(bsxfun(@plus,ZXT, b')),0)];
end
end

function [K]= GaussianKernl(X)

D=pdist2(X',X','euclidean');

K = exp(-D.^2/2);

end


function [K]=cosKerenl(X)

%  A=1-pdist2(X',X','cosine');
normX = sqrt(sum(X.^2,1));
X= bsxfun(@rdivide,X,normX);
A= X'*X;
A= min(A,1);
A=max(A,-1);
K= 1- acos(A)/pi;

end


function [K] = angleKernel(X)

normX = sqrt(sum(X.^2,1));
X= bsxfun(@rdivide,X,normX);
A= X'*X;
A= min(A,1);
A=max(A,-1);
theta = acos( A);

T= sin(theta) + (pi-theta).*cos(theta);
K = bsxfun(@times, bsxfun(@times,T,normX), normX')/pi;

end



