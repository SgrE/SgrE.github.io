function resplot(errorSFS,errorRFF,timeSFS,timeRFF,accSFS,accRFF,len)
%
x = 1:len;
%--------------approximation error-----%
figure(4),
p1 = errorbar(x,mean(errorRFF'),std(errorRFF'),'-.b','linewidth',3);hold on;
p2 = errorbar(x,mean(errorSFS'),std(errorSFS'),'-r','linewidth',3);hold on;
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
%set(gca,'LooseInset',[0,0,0,0]);
xlabel('#random features','fontsize',18);
ylabel('approximation error','fontsize',18);hold on;grid on;
set(gca,'XTickLabel',{'2d','4d','8d','16d','32d'},'Fontsize',18);hold on;
lgd1=legend([p1,p2],'RFF','S-FS+RFF','orientation','horizontal','location','north');
set(lgd1,'FontSize',18);legend boxoff;

%--------------time cost-----%
figure(5),
set(gca,'yscal','log','FontSize',18);hold on;
p1 = errorbar(x,mean(timeRFF'),std(timeRFF'),'-.b','linewidth',3);hold on;
p2 = errorbar(x,mean(timeSFS'),std(timeSFS'),'-r','linewidth',3);hold on;
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
%set(gca,'LooseInset',[0,0,0,0]);
xlabel('#random features','fontsize',18);
ylabel('time cost (sec.)','fontsize',18);hold on;grid on;
set(gca,'XTickLabel',{'2d','4d','8d','16d','32d'},'Fontsize',18);hold on;
lgd1=legend([p1,p2],'RFF','S-FS+RFF','orientation','horizontal','location','north');
set(lgd1,'FontSize',18);legend boxoff;

%--------------test accuracy-----%
figure(6),
p1 = errorbar(x,mean(accRFF'),std(accRFF'),'-.b','linewidth',3);hold on;
p2 = errorbar(x,mean(accSFS'),std(accSFS'),'-r','linewidth',3);hold on;
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
%set(gca,'LooseInset',[0,0,0,0]);
xlabel('#random features','fontsize',18);
ylabel('test accuracy (%)','fontsize',18);hold on;grid on;
set(gca,'XTickLabel',{'2d','4d','8d','16d','32d'},'Fontsize',18);hold on;
lgd1=legend([p1,p2],'RFF','SF-FS+RFF','orientation','horizontal','location','north');
set(lgd1,'FontSize',18);legend boxoff;