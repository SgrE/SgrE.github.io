%% This is a demo of the paper "Towards a unified frmaework for lage-scale kernel machines"
%% writteb by Fanghui Liu, lfhsgre@gmail.com

close all;clear;clc;
addpath('.\CrossValidation\');
%addpath('.\SSR\');
rand('state',0);    randn('state',0);

%%--------1. Dataset Precessing----------------%
%Take the letter dataset as an example
title = 'letter';
[X_train,Y_train,X_test,Y_test] = PrecessingData(title);

%%---------2. Parameter setting----------------%
Iters = 10;% runs
flagCV =0; % cross validation for classifier
n_sample = 1000; % subsample for kernel approximation evaluation

n=size(X_train,1);d = size(X_train,2);
A = X_train'; B = X_test'; % for short


sigma = sqrt(d/2); %Gaussian kernel width: can be cross validation as below
%{
	L_fold = 5;
	[~, index] = sort(rand( length(Y_train), 1));
	X_sub = X_train(index(1:n_sample),:);
	Y_sub = Y_train(index(1:n_sample));
	[bestc, bestg, ~] = automaticParameterSelectionsigma(Y_sub, X_sub, L_fold);
	sigma = bestg;
%}

%initilization
errorDFS = zeros(2,Iters); errorSGQ = zeros(2,Iters); errorRFF = zeros(2,Iters);
timeDFS = zeros(2,Iters); timeSGQ = zeros(2,Iters); timeRFF = zeros(2,Iters);
accDFS = zeros(2,Iters); accSGQ = zeros(2,Iters); accRFF = zeros(2,Iters);
for i = 1:2
    
    if i == 1
        disp('************Part I: third-degree deterministic rules************')
        deg = 1; % third-degree rules
        D = 2*d; %RFF: to ensure the same #random features with third-degree SGQ/DFS
    elseif i == 2
        disp('************Part II: fifth-degree deterministic rules************')
        deg = 2; % fifth-degree rules
        D = 2*d^2; %RFF: to ensure the same #random features with third-degree SGQ/DFS
        
    end
    
    for j = 1:Iters
        %RFF
        [resError,resTime,resAcc] = experiments('rff',D,d,deg,sigma,Y_train,Y_test,n_sample,X_train,X_test,flagCV);
        errorRFF(i,j) = resError; timeRFF(i,j) = resTime; accRFF(i,j) = resAcc;
        
        %third/fifth degree SGQ
        [resError,resTime,resAcc] = experiments('sgq',D,d,deg,sigma,Y_train,Y_test,n_sample,X_train,X_test,flagCV);
        errorSGQ(i,j) = resError; timeSGQ(i,j) = resTime; accSGQ(i,j) = resAcc;
        
        %third/fifth degree DFS
        [resError,resTime,resAcc] = experiments('dfs',D,d,deg,sigma,Y_train,Y_test,n_sample,X_train,X_test,flagCV);
        errorDFS(i,j) = resError; timeDFS(i,j) = resTime; accDFS(i,j) = resAcc;
    end
    
    fprintf('Approximation error (mean��std.): RFF=%.6f��%.6f; SGQ=%.6f��%.6f; DFS=%.6f��%.6f\n',mean(errorRFF(i,:)),std(errorRFF(i,:)),mean(errorSGQ(i,:)),std(errorSGQ(i,:)),mean(errorDFS(i,:)),std(errorDFS(i,:)));
    fprintf('Time cost (mean��std. sec): RFF=%.3f��%.3f; SGQ=%.3f��%.3f; DFS=%.3f��%.3f\n',mean(timeRFF(i,:)),std(timeRFF(i,:)),mean(timeSGQ(i,:)),std(timeSGQ(i,:)),mean(timeDFS(i,:)),std(timeDFS(i,:)));
    fprintf('Test accuracy (mean��std. %%): RFF=%.2f��%.2f; SGQ=%.2f��%.2f; DFS=%.2f��%.2f\n',mean(accRFF(i,:)),std(accRFF(i,:)),mean(accSGQ(i,:)),std(accSGQ(i,:)),mean(accDFS(i,:)),std(accDFS(i,:)));
    
    %-----------------------------------------------------------------------%
    
end
errorbarplot(errorDFS,errorSGQ,errorRFF,timeDFS,timeSGQ,timeRFF,accDFS,accSGQ,accRFF);
pause(1);

disp('************Part III: third-degree stochastic rules for variance reduction (based on RFF)************')

Dset = [2,4,8,16,32]; % #random features Dst*d
len = length(Dset);
errorSFS = zeros(len,Iters); errorRFFS = zeros(len,Iters);
timeSFS = zeros(len,Iters); timeRFFS = zeros(len,Iters);
accSFS = zeros(len,Iters); accRFFS = zeros(len,Iters);

for i = 1:len
    D = Dset(i)*d;
    fprintf('#random features: D=%d*d.........\n',Dset(i));
    for j = 1:Iters
        %RFF
        [resError,resTime,resAcc] = experiments('rff',D,d,deg,sigma,Y_train,Y_test,n_sample,X_train,X_test,flagCV);
        errorRFFS(i,j) = resError; timeRFFS(i,j) = resTime; accRFFS(i,j) = resAcc;
        
        %SFS
        tic;[Z_train,Z_test] = SFSforRFF(d,D,sigma,A,B);
        timeSFS(i,j) = toc;
        errorSFS(i,j) = KernelapproxiEvaluation(Y_train,n_sample,sigma,X_train,Z_train);
        [~,accTest] = RFclassification(Z_train,Z_test,Y_train,Y_test,flagCV);
        accSFS(i,j) = accTest(1);  
    end
    fprintf('Approximation error (mean��std.): RFF=%.6f��%.6f; SFS=%.6f��%.6f\n',mean(errorRFFS(i,:)),std(errorRFFS(i,:)),mean(errorSFS(i,:)),std(errorSFS(i,:)));
    fprintf('Time cost (mean��std. sec): RFF=%.3f��%.3f; SFS=%.3f��%.3f\n',mean(timeRFFS(i,:)),std(timeRFFS(i,:)),mean(timeSFS(i,:)),std(timeSFS(i,:)));
    fprintf('Test accuracy (mean��std. %%): RFF=%.2f��%.2f; SFS=%.2f��%.2f\n',mean(accRFFS(i,:)),std(accRFFS(i,:)),mean(accSFS(i,:)),std(accSFS(i,:)));
    
    
end
disp('************Figure illustration************')
resplot(errorSFS,errorRFFS,timeSFS,timeRFFS,accSFS,accRFFS,len);
%-----------------------------------------------------------------------%
