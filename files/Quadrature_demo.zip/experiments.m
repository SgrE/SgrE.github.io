function [resError,resTime,resAcc] = experiments(type_RF,D,d,deg,sigma,Y_train,Y_test,n_sample,X_train,X_test,flagCV)
%---conduct experiments for approximation error, time cost and accuracy
%% Parameters: 
%type_RF: random features methods, 'rff', 'sgq', 'gq', 'dfs'
%D: #random features
%d: data dimension
%deg: degree
%sigma: kernel width
%Y_train: labels of training data
%Y_test: labels of test data
%n_samples: #subset of training data for approximation
%X_train: training data
%X_test: test data
%flagCV: cross validation

%%
tic;[W,weights] = RandomFeatures(D, d,deg,sigma,type_RF);
Z_train = createRandomFourierFeatures(D, W, weights, X_train',type_RF);
Z_test = createRandomFourierFeatures(D, W, weights, X_test',type_RF);
resTime = toc;
resError = KernelapproxiEvaluation(Y_train,n_sample,sigma,X_train,Z_train);
[~,accTest] = RFclassification(Z_train,Z_test,Y_train,Y_test,flagCV);
resAcc = accTest(1);