function [X_train,Y_train,X_test,Y_test] = PrecessingData(title)

load(['.\dataset\' title '.mat']);

if flagtest == 0 % no training/test split
%training test split
rate = 1/2;Training_num = round(length(Y)*rate);[~, index] = sort(rand( length(Y), 1));
X_train = X( index( end - Training_num+1 : end), : );
Y_train = Y( index( end - Training_num+1: end));
X_test = X( index( 1 : end - Training_num), : );
Y_test = Y( index( 1 : end - Training_num));
end

% normalization to [0,1]^d
X_min = repmat(min( X_train ), [size(X_train, 1),1]); X_max = repmat(max( X_train ), [size(X_train, 1),1]); X_train = (X_train - X_min)./(X_max - X_min);
X_min = repmat(min( X_test ), [size(X_test, 1),1]); X_max = repmat(max( X_test ), [size(X_test, 1),1]); X_test = (X_test - X_min)./(X_max - X_min);
X_train(isnan(X_train)==1) = 0; X_test(isnan(X_test)==1) = 0;