function Z = createRandomFourierFeatures(D, W, weights, X,typeRF)
%CREATERANDOMFOURIERFEATURES creates Gaussian random features or quadrature
% Inputs:
% D the number of features to make
% W, the parameters for those features (d x D)
% X the datapoints to use to generate those features (d x N)
switch typeRF
    case {'dfs','sgq'}
        wa = W'*X;
        tempZ = [cos(wa);sin(wa)];
        weights1 = sqrt(weights);
        temp_weights = [weights1';weights1'];
        Z = bsxfun(@times,temp_weights,tempZ);
        
    otherwise
        Z = sqrt(1/D)*[cos(conj(W')*X);sin(conj(W')*X)];
        
end
end