function error = KernelapproxiEvaluation(Y_train,n_sample,sigma,X_train,Z_train)
[~, index] = sort(rand( length(Y_train), 1));
X_sub = X_train(index(1:n_sample),:);
Z_sub = Z_train(:,index(1:n_sample));

K_sub	= exp(-distf(X_sub,X_sub)*1/(2*sigma^2));  %Gaussian kernel


ZK = (conj(Z_sub')*Z_sub);
error = norm(ZK - K_sub,'fro')/norm(K_sub,'fro');