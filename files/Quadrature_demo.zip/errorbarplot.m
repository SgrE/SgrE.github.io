function errorbarplot(errorDFS,errorSGQ,errorRFF,timeDFS,timeSGQ,timeRFF,accDFS,accSGQ,accRFF)


xt = 1:3;
%--------------approximation error------------------%
figure(1),
meanerror = [mean(errorRFF');mean(errorSGQ');mean(errorDFS')];
stderror = [std(errorRFF');std(errorSGQ');std(errorDFS')];


h = bar(xt,meanerror,1);
f = @(a)bsxfun(@plus,cat(1,a{:,1}),cat(1,a{:,2})).';grid on;
hold on
errorbar(f(get(h,{'xoffset','xdata'})),cell2mat(get(h,'ydata')).',stderror,'.','linewidth',1);
set(gca,'XTickLabel',{'RFF','SGQ','D-FS'},'FontSize',18);hold on;
set(gca,'yscal','log','FontSize',18);hold on;
ylabel('approximation error','fontsize',18);hold on;grid on;
aal = legend(h,'third-degree','fifth-degree','orientation','horizontal','location','north');
set(aal,'FontSize',18);

drawnow;
pause(0.1);

%--------------time cost------------------%
figure(2),
meantime = [mean(timeRFF');mean(timeSGQ');mean(timeDFS')];
stdtime = [std(timeRFF');std(timeSGQ');std(timeDFS')];

h = bar(xt,meantime,1);
f = @(a)bsxfun(@plus,cat(1,a{:,1}),cat(1,a{:,2})).';grid on;
hold on
errorbar(f(get(h,{'xoffset','xdata'})),cell2mat(get(h,'ydata')).',stdtime,'.','linewidth',1);
set(gca,'XTickLabel',{'RFF','SGQ','D-FS'},'FontSize',18);hold on;
set(gca,'yscal','log','FontSize',18);hold on;
ylabel('time cost (sec.)','fontsize',18);hold on;grid on;
aal = legend(h,'third-degree','fifth-degree','orientation','horizontal','location','north');
set(aal,'FontSize',18);
drawnow;
pause(0.1);
%--------------test accuracy------------------%
figure(3),
meanacc = [mean(accRFF');mean(accSGQ');mean(accDFS')];
stdacc = [std(accRFF');std(accSGQ');std(accDFS')];

h = bar(xt,meanacc,1);
f = @(a)bsxfun(@plus,cat(1,a{:,1}),cat(1,a{:,2})).';grid on;
hold on
errorbar(f(get(h,{'xoffset','xdata'})),cell2mat(get(h,'ydata')).',stdacc,'.','linewidth',1);
set(gca,'XTickLabel',{'RFF','SGQ','D-FS'},'FontSize',18);hold on;
%set(gca,'yscal','log','FontSize',14);hold on;
ylabel('test accuracy (%)','fontsize',18);hold on;grid on;
ylim([70,90]);
aal = legend(h,'third-degree','fifth-degree','orientation','horizontal','location','north');
set(aal,'FontSize',18);hold off;
drawnow;
pause(0.1);