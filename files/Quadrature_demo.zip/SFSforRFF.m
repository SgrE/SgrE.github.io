function [Z_train,Z_test] = SFSforRFF(d,D,sigma,A,B)

%-----directly generate the third-degree FSIR-D for
%efficient implementation
%  [ weightsf, points, ~, ~ ] = fwtpts(d, 1); W =
%  points'/(sigma); weights1 = sqrt(weightsf);

dimD = 2*d+1;
weights1 = ones(1,dimD)/sqrt(6); weights1(1) = sqrt(1-d/3);

W = zeros(d,dimD);
generator_lambda = sqrt(3)*[-1,1];
for iij = 1:d
    W(iij,2*iij:2*iij+1) = generator_lambda;
end
W = W'/(sigma);
%---------------------------------------------%

% -----------control of variates-------------%
%-----------basic sampling-------------%
Wrff =  RandomFeatures(D, d,1,sigma,'rff'); Wrff = Wrff';
% it can be further improved by advanced sampling based methods. Here we use
% RFF as an example to illustrate the control of variates.
%------------------------------------------%

% this is not an unbiased estimator
%temp = sum((Wrff*sigma)'.^2);
temp = chi2rnd(D,1,D);

%------generate the related featue mapping matrix
wa = W*A; wb = W*B;
wrffa = Wrff*A; wrffb = Wrff*B;
tempDFStr = [cos(wa);sin(wa)];
tempDFSte = [cos(wb);sin(wb)];
weights11 = [conj(weights1');conj(weights1')];

Z_trainD = bsxfun(@times,weights11,tempDFStr);%D-FS
Z_testD = bsxfun(@times,weights11,tempDFSte);

tempRFtr = [cos(wrffa);sin(wrffa)];
tempRFte = [cos(wrffb);sin(wrffb)];
Z_trainRF = sqrt(1/D)*tempRFtr;%base sampling: RFF
Z_testRF = sqrt(1/D)*tempRFte;


%---Eq.(13)-------%
weights2avg = sqrt(1./(temp'*D/d));
weights2vec = [weights2avg;weights2avg];
Z_trainCoV = bsxfun(@times,weights2vec,tempRFtr);
Z_testCoV = bsxfun(@times,weights2vec,tempRFte);

biaserr = conj(Z_trainCoV(:,1)')*Z_trainCoV(:,1); % correct the bias due to the unnormalized weights
Z_trainCoV = Z_trainCoV/sqrt(biaserr);
Z_testCoV = Z_testCoV/sqrt(biaserr);


%-----------generate the final feature mapping Eq.(16)

copt = 1;%it can be optimized 
Z_train = [Z_trainRF;copt*1i*Z_trainCoV;copt*Z_trainD];
Z_test = [Z_testRF;copt*1i*Z_testCoV;copt*Z_testD];
