# Towards a Unified Quadrature Framework for Large-Scale Kernel Machines
# Written by Fanghui Liu, lfhsgre@gmail.com

This repository maintains a demo of the paper [Towards a Unified Quadrature Framework for Large-Scale Kernel Machines](https://arxiv.org/abs/2011.01668).

## Run
One can directly run the main function `demo.m` on the `letter` dataset across the Gaussian kernel for evaluation. More datasets can be downloaded from the links listed in the paper, and then added into the path '.\dataset\'. 

The demo includes three parts:
Part I: generates third-degree sparse grids quadrature (SGQ) with 2d+1 nodes, deterministic fully symmetric intepolatory rule (D-FS) with 2d+1 nodes, RFF with 2d nodes for evaluation.
Part II: generates fifth-degree SGQ with 1+2d^2+2d nodes, D-FS with 1+2d^2 nodes, RFF with 2d^2 nodes for evaluation.
Part III: generates stochastic fully symmetic intepolatory rule (S-FS) equipped with Monte-Carlo sampling and RFF for evaluation.

## Parameters
The parameters include:
title: filename of the dataset
deg: the accuracy level
D: the number of random features
sigma: the kernel width

## Matlab implementation for SSR
We also provide the Matlab implementation of the paper [Quadrature-based features for kernel approximation](https://papers.nips.cc/paper/2018/hash/6e923226e43cd6fac7cfe1e13ad000ac-Abstract.html). It can be conducted as below.

%[M, w,Ddimen] = butt_quad_mapping([X_train',X_test'],Dk, 1);
%M = M/sigma;
%temp_weights = [w';w'];
%Mapping = bsxfun(@times,temp_weights,[cos(M);sin(M)])/sqrt(Ddimen);
%Z_train = Mapping(:,1:size(X_train,1));
%Z_test = Mapping(:,size(X_train,1)+1:end);
                
