function thetas = butterfly_angles(u)
%Computes angles (in radians) from components of the generating vector `u` for random butterfly orthogonal matrices.
% 
%     Args:
%     =====
%     u: a generating vector for random butterfly orthogonal matrices, use
%         make_generating_vector() to obtain one.
% 
%     Returns:
%     ========
%     thetas: an 1-D array of angles for computing random butterfly orthogonal
%         matrices.

    thetas = atan2(u(1:end-1), u(2:end));