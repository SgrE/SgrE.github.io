function Mx = get_batch_mx(x, cosf, sinf, perm)
    b = batch_butterfly_matvec(x, cosf, sinf, perm);
    Mx = batch_simplex_matvec(b);