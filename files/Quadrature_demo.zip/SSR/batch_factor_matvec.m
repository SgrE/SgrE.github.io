function r = batch_factor_matvec(x, n, cosf, sinf)
%    Matvec for Q_n^T x, where n is the index number of n'th factor
%        of butterfly matrix Q. Facilitates fast butterfly simplex weights
%        multiplication by data vector:
%        [QV]^T x = V^T Q^T x = V^T Q_{log2(d)}^T ... Q_0^T x

%    Args:
%    x: a batch of data vectors
%    n: the index number of n'th butterfly factor Q_n
%    cos: cosines used to generate butterfly matrix Q
%    sin: sines used to generate butterfly matrix Q

nobj = size(x,2);
N = size(x,1);
d = length(cosf) + 1;
blockn = 2^n;
nblocks = ceil(N/blockn);
r = x;
step = floor(blockn/2);
for i=0:nblocks - 2
    shift = blockn*i;
    idx = step + shift - 1;
    c = cosf(idx+1);
    s = sinf(idx+1);
    for j = 0:step-1
        i1 = shift + j;
        i2 = i1 + step;
        for o=0:nobj-1
            y1 = x(i1+1, o+1);
            y2 = x(i2+1, o+1);
            r(i1+1, o+1) = c * y1 + s * y2;
            r(i2+1, o+1) = -s * y1 + c * y2;
        end
    end
end

%r = fix(r);

% # Last block is special since N might not be a power of 2,
%  # which causes cutting the matrix and replacing some elements
%   # with ones.
%   # We calculate t - the number of lines to fill in before proceeding.

i = nblocks - 1;
shift = blockn * i;
idx = step + shift - 1;
c = cosf(idx+1);
s = sinf(idx+1);
t = N - shift - step;
for j=0:t - 1
    i1 = shift + j;
    i2 = i1 + step;
    for o=0:nobj-1
        y1 = x(i1+1, o+1);
        y2 = x(i2+1, o+1);
        r(i1+1, o+1) = c * y1 + s * y2;
        r(i2+1, o+1) = -s * y1 + c * y2;
    end
end

%r = fix(r);
