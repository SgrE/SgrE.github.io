function r = batch_simplex_matvec(x)
%x: d*n data matrix
    nobj = size(x,2);
    d = size(x,1);
    mp = d + 1;
    r = zeros(d+1, nobj);
    rv = zeros(1,d);
    s = zeros(1,nobj);
    for i=0:d-1
        rv(i+1) = sqrt(mp / ((d-i) * d * (d-i+1)));
        for o = 0:nobj-1
            rvo = rv(i+1) * x(i+1,o+1);
            r(i+1, o+1) = s(o+1) + rvo * (d-i);
            s(o+1) = s(o+1) - rvo;
        end
    end
    for o=0:nobj-1
        r(d+1, o+1) = s(o+1);
    end