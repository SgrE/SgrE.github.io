close all
clear all
rand('state',0);    randn('state',0);
load(['.\LFW_10Class.mat']);
fea = LFW_10Class(:,1:end-1);
gnd = LFW_10Class(:,end);
class_num = max(gnd(:));
select_num =5;
example_num = length(gnd)/class_num;

tau = 0.01;
CV_flag =1;
Iternum =1;
res_svm_train = zeros(1,Iternum);
res_svm_test = zeros(1,Iternum);
res_ours_train = zeros(1,Iternum);
res_ours_test = zeros(1,Iternum);
for sss = 1:Iternum
    
    sss
    trainIdx = [];
    for i = 1:class_num
        indtemp = find(gnd==i);
        temp1 = indtemp(1);  temp2 = indtemp(end);
        select_train=randi([temp1,temp2],select_num,1);
        trainIdx = [trainIdx;select_train];
    end
    Idx = 1:length(gnd); Idx = Idx';
    testIdx = setdiff(Idx,trainIdx);
    X_train_s = double(fea(trainIdx,:));
    X_test_s = double(fea(testIdx,:));
    
    Y_train_s = gnd(trainIdx);
    Y_test_s = gnd(testIdx);
    
    
   %train SVM for each class
    label_tr_cv = zeros(size(X_train_s,1),class_num);  label_tr_ws = label_tr_cv; h_tr_cv =  label_tr_cv;h_tr_ws =  label_tr_ws;
    label_te_cv = zeros(size(X_test_s,1),class_num);  label_te_ws = label_te_cv;h_te_ws =  label_te_ws;h_te_cv =  label_te_cv;
    temp_ind = 0;
    for kki = 1:class_num
       % for kkj = kki+1:class_num
            temp_ind = temp_ind + 1;
            indp_tr = find(Y_train_s==kki); indn_tr = find(Y_train_s~=kki);
            indp_te = find(Y_test_s==kki); indn_te = find(Y_test_s~=kki);
            Y_train = Y_train_s([indp_tr;indn_tr]); Y_train(Y_train~=kki) = -1; Y_train(Y_train==kki) = 1; 
            X_train = X_train_s([indp_tr;indn_tr],:);
            Y_test = Y_test_s([indp_te;indn_te]); Y_test(Y_test~=kki) = -1; Y_test(Y_test==kki) = 1;
            X_test = X_test_s([indp_te;indn_te],:);
            n=size(X_train,1);
            m = size(X_train,2);
            ntest=size(X_test,1);

            L_fold = 5;
            if CV_flag == 1
                [bestc, bestg, bestcv] = automaticParameterSelection(Y_train, X_train, L_fold);
                C = bestc; sigma = bestg;
            else
                C =181.0193; sigma =0.17678;
            end
            libsvmparam1 = ['-s 0 -c ',num2str(C), ' -t 2', ' -g ', num2str(sigma)];
            model_CV = svmtrain(Y_train,X_train,libsvmparam1);
            [res_tr_cv,accuracy_SVM_CV_train, h] = svmpredict( Y_train,  X_train, model_CV);
            res_tr_cv(res_tr_cv==1)=kki; res_tr_cv(res_tr_cv==-1)=-1;
            label_tr_cv([indp_tr;indn_tr], temp_ind) = res_tr_cv;
            h_tr_cv([indp_tr;indn_tr], temp_ind) = h;
            [res_te_cv,accuracy_SVM_CV_test, h] = svmpredict( Y_test,  X_test,model_CV);
            res_te_cv(res_te_cv==1)=kki; res_te_cv(res_te_cv==-1)=-1;
            label_te_cv([indp_te;indn_te], temp_ind) = res_te_cv;
            h_te_cv([indp_te;indn_te], temp_ind) = h;
            %-----------------------------------------------------------------------------------------------%
            
            ktrain1 = create_kernel(X_train,X_train,'gauss',sigma);
            Ktrain = [(1:n)',ktrain1];
            ktest1 =create_kernel(X_test,X_train,'gauss',sigma);
            Ktest = [(1:ntest)', ktest1];
            
            sigma_train = ones(n,n);
            sigma_test = zeros(ntest,n);
            alpha_c = zeros(n,1);
            
            alpha_c( model_CV.sv_indices,:) =  model_CV.sv_coef;
            if size(alpha_c,1) ~= n
                alpha_c =  alpha_c';
            end
            alpha = alpha_c./Y_train;
             gamma = 1*sum(alpha.^2);
            value = [];
            for j = 1:1
                
                %-----------------ADMM------------------------------------------%
                S = sigma_train;
                P = 1/4/gamma*diag(alpha'*diag(Y_train))*Ktrain(:,2:end)*diag(alpha'*diag(Y_train));
                Q = zeros(n,n);
                Z = zeros(n,n);
                MaxIter = 15;tol=1e-3;iter = 0;
                beta = 1;rho=1.1;betaUpperThreshold=1e8;
                converged = false;
                Diff = [];
                while ~converged
                    
                    iter = iter + 1;
                    Q_old = Q;
                    Z_old = Z;
                    S_old = S;
                    
                    matrix1 = 1/(1+beta)*(beta*Q+Z+P);
                    %             [u,v] = eig(matrix1);
                    %             S = u*max(v,0)*u';
                    
                    [u,d,v] = svd(matrix1);
                    dd = diag(d)-tau;
                    S = u*max(0,diag(dd))*v';
                    
                    S = real(S);
                    
                    matrix2 = 1/(1+beta)*(beta*S-Z+P);
                    matrix2 = matrix2';
                    
                    for kk = 1:n
                        Q(:,kk) = (2* matrix2(:,kk)*ones(1,n) - 2*n*eye(n))\(n*ones(n,1));
                        Q(:,kk)= n*Q(:,kk)/sum(Q(:,kk));
                    end
                    Q = Q';
                    
                    Z = Z - beta*(S - Q);
                    
                    beta = min(beta*rho,betaUpperThreshold);
                    
                    %% stopping criterion
                    Diff(iter) = max(norm(Q-Q_old,'fro'),norm(Z-Z_old,'fro'));
                    %Diff(iter) = norm(S-S_old,'fro');
                    if (Diff(iter)<tol) || (iter == MaxIter)
                        sigma_train = S;
                        converged = true;
                    end
                    
                    %% display
                    disp(['Conducting Iteration ' num2str(iter)]);
                    
                    
                end
                %---------------------------------------------------------------------------------------------%
                
                
                %--------Ktrain--------------------%
                ktrain = sigma_train.*ktrain1;
                Ktrain = [(1:n)',ktrain];
                
                %-----------Ktest-------------------%
                dictionary = X_train';
                nbase = size(dictionary,2);
                data = X_test';
                ns     = size(data,2);
                XX = sum(data.^2);
                BB = sum(dictionary.^2);
                
                D = repmat(XX,nbase,1) - 2*dictionary'*data + repmat(BB',1,ns);
                num = 1;
                IDX = zeros(ns, num);
                temss = [];
                for i = 1:ns
                    d = D(:,i);
                    [~, idx ] = sort(d, 'ascend');
                    temss = [  temss d(idx(1))];
                    IDX(i,:) = idx(1:num);
                    sigma_test(i,:) = sigma_train(IDX(i),:);
                end
                
                ktest = sigma_test.* ktest1;
                %ktest = ktest1;
                Ktest = [(1:ntest)', ktest];
                %------------------------------%
                
                %----------------------------------------%
                libsvmparam = ['-s 0 -c ',num2str(C), ' -t 4'];
                model_sigma = svmtrain(Y_train, Ktrain,libsvmparam);
                [res_tr_ws, accuracy_ours_train, h1] = svmpredict(Y_train, Ktrain, model_sigma);
                [res_te_ws, accuracy_ours_test, h2] = svmpredict(Y_test, Ktest, model_sigma);
                res_tr_ws(res_tr_ws==1)=kki; res_tr_ws(res_tr_ws==-1)=-1;
                res_te_ws(res_te_ws==1)=kki; res_te_ws(res_te_ws==-1)=-1;
                
                label_tr_ws([indp_tr;indn_tr], temp_ind) = res_tr_ws;
                label_te_ws([indp_te;indn_te], temp_ind) = res_te_ws;
                h_tr_ws([indp_tr;indn_tr], temp_ind) = h1;
                h_te_ws([indp_te;indn_te], temp_ind) = h2;
                
                alpha_c(model_sigma.sv_indices) = model_sigma.sv_coef;
                if size(alpha_c,1) ~= n
                    alpha_c =  alpha_c';
                end
                alpha = alpha_c./Y_train;
                A = alpha'*diag(Y_train);
                value=[value,-1/2*A*(sigma_train.*Ktrain(:,2:end))*A'+sum(alpha)+gamma/2*norm(sigma_train,'fro')];
            end
        %end
    end
    Y_svm_train = compute_res_new(label_tr_cv,h_tr_cv);
    Y_svm_test = compute_res_new(label_te_cv,h_te_cv);
    Y_ours_train = compute_res_new(label_tr_ws,h_tr_ws);
    Y_ours_test = compute_res_new(label_te_ws,h_te_ws);
    [aq,~]=find(Y_svm_train==Y_train_s); res_svm_train(sss) = length(aq)/length(Y_train_s)*100;
    [aq,~]=find(Y_svm_test==Y_test_s); res_svm_test(sss) = length(aq)/length(Y_test_s)*100;
    [aq,~]=find(Y_ours_train==Y_train_s); res_ours_train(sss) = length(aq)/length(Y_train_s)*100;
    [aq,~]=find(Y_ours_test==Y_test_s); res_ours_test(sss) = length(aq)/length(Y_test_s)*100;
end
fprintf('C=%f Sigma=%f\n',C,sigma);
fprintf('SVM: Training Process Accuracy: ACC=%f��%f\n',mean(res_svm_train),std((res_svm_train)));
fprintf('SVM: Test Process Accuracy:  ACC=%f��%f\n',mean(res_svm_test),std((res_svm_test)));
fprintf('Ours: Training Process Accuracy=%f��%f\n',mean(res_ours_train),std((res_ours_train)));
fprintf('Ours: Test Process Accuracy=%f��%f\n',mean(res_ours_test),std((res_ours_test)));
