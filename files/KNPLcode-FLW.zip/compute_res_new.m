function Y = compute_res_new(label,hmap)
num = size(label,1);
Y = zeros(num,1);
for i = 1:num
    %         temp1 = label(i,:);
    %         table=tabulate(temp1);
    %         [~,b]=sort(table(:,3),'descend');
    %         MaxValue=table(b(2),1);
    %          Y(i) = MaxValue;
    temp1 = label(i,:);
    indx = find(temp1~=-1);
%     if length(indx) == 1
%         Y(i) = indx;
%     else
        h = hmap(i,:);
        [~,ind] = max(h);
        Y(i) = temp1(ind(1));
%    end
end