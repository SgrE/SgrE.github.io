﻿This repository maintains the code of our paper Nonlinear Pairwise Layer and Its Training for Kernel Learning on the LFW face recogniton dataset.

Directly run main_LFW.m

Parameters
select_num: the number of seclected samples in each class
tau: the low rank regularization parameter
CV_flag: whether to use cross validation
Iternum: the iteration number
gamma: the regularization parameter

