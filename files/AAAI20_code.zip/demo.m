
close all
clear all
rand('state',0);    randn('state',0);

typeRF = 'sle-rff'; % rff qmc le-rff sle-rff(Ours)
typeC = 'lr'; % ;lr liblinear
flagCV =0;

Iternum =10;
sigma = 1;
res = zeros(1,Iternum);
time_acc = zeros(1,Iternum);
approxi_res = zeros(1,Iternum);

for sss = 1:Iternum
    
    sss
    duration = 0;
    
    title = 'EEG';%mapstd
    load([title '.mat'])
    
    if flagtest == 0
        rate = 1/2;
        Training_num = round(length(Y)*rate);
        [~, index] = sort(rand( length(Y), 1));
        X_train = X( index( end - Training_num+1 : end), : );
        Y_train = Y( index( end - Training_num+1: end));
        X_test = X( index( 1 : end - Training_num), : );
        Y_test = Y( index( 1 : end - Training_num));
        
        %X_min = repmat(min( X_train ), [size(X_train, 1),1]); X_max = repmat(max( X_train ), [size(X_train, 1),1]); X_train = (X_train - X_min)./(X_max - X_min);
        %X_min = repmat(min( X_test ), [size(X_test, 1),1]); X_max = repmat(max( X_test ), [size(X_test, 1),1]); X_test = (X_test - X_min)./(X_max - X_min);
        X_train = mapstd(X_train); X_test = mapstd(X_test);
    else
        %         X_train = X; Y_train = Y;
        % X_train = mapstd(X_train); X_test = mapstd(X_test);
        %    X_min = repmat(min( X_train ), [size(X_train, 1),1]); X_max = repmat(max( X_train ), [size(X_train, 1),1]); X_train = (X_train - X_min)./(X_max - X_min);
        %    X_min = repmat(min( X_test ), [size(X_test, 1),1]); X_max = repmat(max( X_test ), [size(X_test, 1),1]); X_test = (X_test - X_min)./(X_max - X_min);
    end
    
    n=size(X_train,1);
    d = size(X_train,2);
    
    
    ytrain = Y_train;
    ytest = Y_test;
    
    D =8*d;
    b = rand(1,D)*2*pi;
    tic;
    
    W = RandomFeatures(D, d,sigma,typeRF);
    switch typeRF
        case 'le-rff' %ICML2019
            [Z_train,Z_test]= leverageRFF(D, W, b, X_train',X_test');
        case 'sle-rff' %Ours
            [Z_train,Z_test]= SERLSRFF(D, W, b, X_train',X_test',Y_train);
        otherwise
            Z_train = createRandomFourierFeatures(D, W, b, X_train',typeRF);
            Z_test = createRandomFourierFeatures(D, W, b, X_test',typeRF);
            
    end
    duration = duration + toc;
    
    %%Classification
    [accTrain, accTest] = RFclassification(Z_train,Z_test,Y_train,Y_test,flagCV);
    
    res(sss) = accTest;
    time_acc(sss) = duration;
end
fprintf('Test Process Accuracy:  ACC= %.2f��%.2f (%.2f��%.2f)\n',mean(res),std(res),mean(time_acc),std(time_acc));
