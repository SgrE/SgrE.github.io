function Z = createRandomFourierFeaturesRKKS(D, W, W1, b, X,spos,sneg) 
%CREATERANDOMFOURIERFEATURES creates Gaussian random features

Z = sqrt(1/D)*[sqrt(spos)*cos(bsxfun(@plus,W'*X, b'));sqrt(spos)*sin(bsxfun(@plus,W'*X, b'));sqrt(sneg)*1i*cos(bsxfun(@plus,W1'*X, b'));sqrt(sneg)*1i*sin(bsxfun(@plus,W1'*X, b'))];

end