
function [W1,W2,spos,sneg] = samplingpolysp(D,d,p,a)
tau = 2;
knot = D*d;
spoint = knot * 10;

tt=linspace(-10,10,10000);
for i = 1:2
    if i == 1%besselj
        fx1 = @(x) min(10,max(0,(2*pi)^(-d/2)*((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,[(2*tau+1)*x]) + (2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,[(2*tau+1)*x]) ) ));
        ff=fx1(tt);%
        spos = abs(trapz(tt,ff));
    else
        
        fx2 = @(x) -min(0,(2*pi)^(-d/2)*((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,[(2*tau+1)*x]) + (2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,[(2*tau+1)*x],1)) );
        ff=fx2(tt);%
        sneg = abs(trapz(tt,ff));
    end
end

fx1 = @(x) 1/spos*min(10,max(0,(2*pi)^(-d/2)*((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,(2*tau+1)*x) + (2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,(2*tau+1)*x,1))));
fx2 = @(x) -1/sneg*min(0,(2*pi)^(-d/2)*((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,(2*tau+1)*x) + (2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,(2*tau+1)*x,1)));

for i = 1:2
    a = zeros(0); %ypro = zeros(0);
    while length(a) < knot
        x=random('unif',-10,10,1,spoint);
        y=random('unif',0,1,1,spoint);
        if i==1
            f=fx1(x);
        else
            f = fx2(x);
        end
        
        temp = y<=f;
        b = x(temp);
        a = [b,a];
        
        %ypro = [ypro,y(temp)];
        if length(a)>= knot
            break;
        end
    end
    tempa = a(1:knot);
    W = reshape(tempa,d,D);
    if i == 1
        W1 = W;
    else
        W2 = W;
    end
end


