close all
clear all
addpath('D:\liblinear-2.20\matlab\');
rand('state',0);    randn('state',0);
savepath  = ['.\Results\'];

flagCV =0;

typeC = 'lr'; % ;lr liblinear
P = 1; a = 2; % polynomial kernel on unit sphere
setd = [2,4,8];
%setd = 1*[2,4,8,16,32];
Iternum =10;
res = zeros(length(setd),Iternum);
time_acc = zeros(length(setd),Iternum);
approxi_res = zeros(length(setd),Iternum);
for jjj = 1:length(setd)
    kkm = setd(jjj);
    n_sample = 1000;
    typeker = 'polysp'; a = 2;
    flagtest = 1;
    
    title = 'letter';
    load([ title '.mat'])
    
    sigma = 1;
    
    X_train = X_train./repmat(sqrt(sum(X_train.^2,2)),1,size(X_train,2));
    X_test = X_test./repmat(sqrt(sum(X_test.^2,2)),1,size(X_test,2));
    
    %    title = 'EEG';
    %    load([ 'E:\UCI\' title '.mat'])
    
    %title = 'covtype'; [y X] = libsvmread('E:/UCI/covtype.libsvm.binary.scale');
    %[y X] = libsvmread('E:/UCI/SUSY');
    %     y(y==2)=-1;
    %     l = size(X,1);
    
    
    for sss = 1:Iternum
        
        sss
        duration = 0;
        
        n=size(X_train,1);
        d = size(X_train,2);
        m = size(X_test,1);
        
        D =kkm*d;
        b = zeros(1,D);
        
        tic;
        [W1,W2,spos,sneg] = samplingpolysp(D,d,P,a);
        spos = spos/(spos+sneg); sneg = sneg/(spos+sneg);
        
        Z_train = createRandomFourierFeaturesRKKS(D, W1,W2, b, X_train',spos,sneg);
        Z_test = createRandomFourierFeaturesRKKS(D, W1,W2, b, X_test',spos,sneg);
        
        duration = duration + toc;
        [accTrain, accTest] = RFclassificationRKKS(Z_train,Z_test,Y_train,Y_test,typeC,flagCV);
        
        res(jjj,sss) = accTest;
        time_acc(jjj,sss) = duration;
        
        
        %% kernel approximation
        
        [~, index] = sort(rand( length(Y_train), 1));
        X_sub = X_train(index(1:n_sample),:);
        Z_sub = Z_train(:,index(1:n_sample));
        
        K_sub = create_kernel(X_sub,X_sub,'polysp',P,a);
        ZK = (conj(Z_sub')*Z_sub);
        
        temp = ones(1,size(ZK,1));
        ZK = ZK - diag(diag(ZK)) + diag(temp);
        
        error = norm(K_sub - ZK,'fro')/norm(K_sub,'fro');
        approxi_res(jjj,sss) = error;
        
        clear Z_train Z_test
        
    end
    
    clear X_train X_test Y_train Y_test
    res_trials = res(jjj,:);
    time_trials = time_acc(jjj,:);
    app_trials = approxi_res(jjj,:);
    %save([savepath title '_' typeRF '_' typeC '_' num2str(kkm) 'd','.mat'], 'res_trials','time_trials','app_trials');
end

for j = 1:length(setd)
    kkm = setd(j);
    fprintf('%.2f��%.2f (%.2f��%.2f) (%.3f��%.3f)\n',mean(res(j,:)),std(res(j,:)),mean(time_acc(j,:)),std(time_acc(j,:)),mean(approxi_res(j,:)),std((approxi_res(j,:))));
end