function distance = distf(X,Y)
nx	= size(X,1);
ny	= size(Y,1);
distance=sum((X.^2),2)*ones(1,ny) +ones(nx,1)*sum((Y.^2),2)' - 2*(X*Y');