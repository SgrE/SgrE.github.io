# On the double descent of random features models trained with SGD

This repository maintains two demos of our submission.

## Run
It includes two demos, one is `demo_MNIST` on the [MNIST](http://yann.lecun.com/exdb/mnist/) dataset which is also included in our code; and the other is `demo_synthetic` on a synthetic regression dataset. One can directly run them.

These two demo evaluate the test MSE of random features regression under the minimum norm solution and averaged SGD with polynomial decay step-size and one (or more) epochs on different datasets, which aims to show the double descent curve.

