%% Demo of the paper "On the double descent of random features models trained with SGD" on MNIST dataset

close all
clear all\
rand('state',0);    randn('state',0);


flagCV =0;
typeRF = 'rff';

lambda = 1e-8;% regularization parameter
td = 600; % training data
NS = [10,20,50,80,100,150,200,250,280,320,350,400,500,700,800,1000,1200];  % the number of random features

gamma0sgd = 1;%initial stepsize
zetasgd = 0.5;  % step-size parameter 

Iternum =5; % running times
epoch = 10; % number of epoch



title = 'mnist';
load([ './' title '.mat'])
X_train = Xdata; X_test = Xtestdata; Y_train = Xlabel; Y_test = Xtestlabel;
d = size(X_train,2);
X_train = mapstd(X_train);X_test = mapstd(X_test);

%% choose data of two classes for regression
posdigit = 3; 
negdigit = 7;
[indtrp] = find(Y_train==posdigit); [indtrn] = find(Y_train==negdigit);
[indtep] = find(Y_test==posdigit); [indten] = find(Y_test==negdigit);

indtrp = indtrp(1:td/2); indtrn = indtrn(1:td/2);

train_num = length(indtrp) + length(indtrn);
test_num = length(indtep) + length(indten);

X_trainpos = X_train(indtrp,:); X_trainneg = X_train(indtrn,:);
X_train =[X_trainpos;X_trainneg];
Y_train = zeros(train_num,1);
Y_train(1:length(indtrp)) = 1; Y_train(length(indtrp)+1:end) = -1;


X_testpos = X_test(indtep,:); X_testneg = X_test(indten,:);
X_test =[X_testpos;X_testneg];
Y_test = zeros(test_num,1);
Y_test(1:length(indtep)) = 1; Y_test(length(indtep)+1:end) = -1;

res = zeros(1,length(NS)); res_e = res;
res_minnorm = res; res_minnorm_e = res;
res_diff = res;

for i = 1:length(NS)
    i
    nsample = NS(i);
    n = size(X_train,1);
    error = zeros(1,Iternum); error_minnorm = error;
    for j = 1:Iternum
        p = randperm(train_num);
        
        % Random features
        D =nsample;
        b = rand(1,D)*2*pi;
        sigma = sqrt(d);
        W = RandomFeatures(D, d,sigma,typeRF);
        Z_train = createRandomFourierFeatures(D, W, b, X_train',typeRF,'rbf');
        Z_test = createRandomFourierFeatures(D, W, b, X_test',typeRF,'rbf');
       
        %% -- min norm solution %%
         w_minnorm = (Z_train * Z_train' + lambda * eye(size(Z_train,1))) \ (Z_train * (Y_train));
         y_pred = (Z_test'*w_minnorm);  signal_norm = norm(w_minnorm)/(2*NS(1)); % noramlized energy of optimal solution
        error_minnorm(j) = mean((y_pred - Y_test).^2);
        
        %% --- average SGD--------------%%
        wt1 =  w_minnorm+randn(size(Z_train,1),1); %initlization around min-norm solution with Gaussian noise
        %wt1 = ones(size(Z_train,1),1)*signal_norm; % constant initlization
            wtotal = zeros(epoch*n,size(Z_train,1));
            mainf = zeros(epoch*n,1);
            for id = 1:epoch*n
                t = mod(id,n);
                if t == 0
                    t = n;
                end
                gammat = gamma0sgd*t^(-zetasgd);
                mainf(t) = 1/2*norm(Y_train - Z_train'*wt1)^2 + 1/2*lambda*norm(wt1)^2;
                gradf = (Z_train(:,t)'*wt1 -Y_train(t))*Z_train(:,t) + lambda*wt1;
                % - if we use so-called optimal step size
                %gammat = norm(gradf)^2 / (gradf'*(Z_train*Z_train'+ lambda * eye(size(Z_train,1)))*gradf);
                wt = wt1 - gammat* gradf;
                wtotal(id,:) = wt';
                wt1 = wt;
            end
            w = mean(wtotal); w = w';
            %norm(w - w_minnorm)
        
        %% --- prediction
        y_pred = (Z_test'*w);
        error(j) = mean((y_pred - Y_test).^2);
        
       
    end
    
    res(i) = mean(error); res_e (i) = std(error);
    res_minnorm(i) = mean(error_minnorm); res_minnorm_e (i) = std(error_minnorm);
    res_diff(i) = norm(w-w_minnorm)/norm(w_minnorm);
   
end
figure(1), errorbar(NS/n,res_minnorm,res_minnorm_e,'-r');grid on;hold on;
errorbar(NS/n,res,res_e,'-.b');grid on;hold on;
legend('min-norm solution','SGD');hold on;
xlabel('m/n','fontsize',18);ylabel('Test MSE','fontsize',18);grid on;

