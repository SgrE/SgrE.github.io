function Z = createRandomFourierFeatures(D, W, b, X,typeRF,typeker) 
%CREATERANDOMFOURIERFEATURES creates Gaussian random features
% Inputs:
% D the number of features to make
% W, b the parameters for those features (d x D and 1 x D)
% X the datapoints to use to generate those features (d x N)
    %Z = sqrt(2/D)*cos(bsxfun(@plus,W'*X, b'));
    %Z = sqrt(1/D)*cos(bsxfun(@plus,W'*X, b'));
   % Z = sqrt(1/D)*[cos(bsxfun(@plus,W'*X, b'));sin(bsxfun(@plus,W'*X, b'))];
   switch typeRF
       case 'lp-rff'
           Z = sqrt(1/D)*[cos(bsxfun(@plus,W'*X, b'));sin(bsxfun(@plus,W'*X, b'))];
           n = size(Z,2);
           bits = 5;
           len = 2/(2^bits-1)/sqrt(D);
           c=-1/sqrt(D):len:1/sqrt(D);
           Za = Z(:);
           codebook=[c,1000];
           [~,qZa] = quantiz(Za,c,codebook); %qZa: quatize to sup
           qZa = qZa';
           qZb = max(-1/sqrt(D),qZa - len); % qZb: quatize to inf
           probinf = 1 - (qZa - Za)/len; % the probability of quatize to inf
           temp = rand(n*2*D,1); tempa = zeros(n*2*D,1);
           tempa(probinf<temp) = 1;
           tempb = 1 - tempa;
           Za = tempa.*qZb + tempb.*qZa;%obtain the quatize vector
           Z = reshape(Za,2*D,n);
           %{
           Za = Z(1:D,:); Za = Za(:);
           codebook=[c,1000];
           [~,qZa] = quantiz(Za,c,codebook); %qZa: quatize to sup
           qZa = qZa';
           qZb = max(-1/sqrt(D),qZa - len); % qZb: quatize to inf
           %probsup = (qZa - Za)/len; % the probability of quatize to sup
           probinf = 1 - (qZa - Za)/len; % the probability of quatize to inf
           temp = rand(n*D,1); tempa = zeros(n*D,1);
           tempa(probinf<temp) = 1;
           tempb = 1 - tempa;
           Za = tempa.*qZb + tempb.*qZa;
           Za = reshape(Za,D,n);
           
           Zc = Z(D+1:end,:); Zc = Zc(:);
           [~,qZa] = quantiz(Zc,c,codebook); %qZa: quatize to sup
           qZa = qZa';
           qZb = max(-1/sqrt(D),qZa - len); % qZb: quatize to inf
           Zc = tempa.*qZb + tempb.*qZa;
           Zc = reshape(Zc,D,n);
           
           Z = [Za;Zc];
           %}
           case 'fsirnew'
               deg = 1;
               
               d = size(W,1);
               t = D/d/2;
               b = rand(1,size(W,2)-1)*2*pi*0;
               [ weights, W, ~, ~ ] = fwtpts(d, deg);
               a0 = weights(1); weights = weights(2:end);
               W = 2*W(:,2:end);
               Z = 1/sqrt(t*D)*[cos(bsxfun(@plus,W'*X, b'));sin(bsxfun(@plus,W'*X, b'))];
               %Z = sqrt(1/2)*bsxfun(@times,Z,[weights';weights']);
               %z = sqrt(2)/2*ones(1,size(Z,2));
               %Z = [z;Z];
               %Z = [cos(bsxfun(@plus,W'*X, b'));sin(bsxfun(@plus,W(:,2:end)'*X, b(2:end)'))];
               %Z = bsxfun(@times,Z,[weights';weights(2:end)']);
               
               Z = repmat(Z,t,1);
       otherwise
           if strcmp(typeRF,'nrff')
               X = X./repmat(sqrt(sum(X.^2,2)),1,size(X,2));
           end
           if strcmp(typeker,'rbf')
               Z = sqrt(1/D)*[cos(bsxfun(@plus,conj(W')*X, b'));sin(bsxfun(@plus,conj(W')*X, b'))];
           elseif  strcmp(typeker,'arccos1')
               Z = sqrt(2/D)*[max(bsxfun(@plus,conj(W')*X, b'),0)];%max(bsxfun(@plus,conj(W')*X, b'),0)];
           elseif  strcmp(typeker,'arccos0')
               Z = sqrt(1/D)*[max(sign(bsxfun(@plus,conj(W')*X, b')),0);max(sign(bsxfun(@plus,conj(W')*X, b')),0)];
           elseif strcmp(typeker,'ntksp')
               temp = conj(W')*X;
               temp1 = sign(temp); temp1(temp1<0) = 0;
               
               Z1 = sqrt(2/D)*[max(bsxfun(@plus,temp, b'),0);max(bsxfun(@plus,temp, b'),0)];
           end
   end
end