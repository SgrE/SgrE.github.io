function W = RandomFeatures(D, d,sigma,typeRF,typeker)

switch typeRF
    case {'rff','lp-rff','nrff','le-rff','opt-rff','dpp-rff','sle-rff'} %Classic random fourier features (DEFAULT)
        W = randn(d,D)/sigma;
    case 'scrf'
        k = round(D/d);
        W = zeros(d,D);
        for i = 1:k
            v = sign(randn(d,1));
            w = randn(d,1);
            F = dftmtx(d);
            C = 1/d*F'*diag(F*w)*F;
            W(:,(i-1)*d+1:i*d) = C;
        end
    case 'qmc'
        %   scram: scramble the sequence or not
        %   skip, leap: properties in sequences that might affect the final accuracy
        leap = 700; skip = 1000; scram = 1;
        sequence = 'halton';
        switch sequence
            case 'halton'
                p = haltonset(d,'Skip',skip,'Leap',leap);
                if scram p = scramble(p,'RR2'); end
                points = p(1:D,1:d);
            case 'sobol'
                p = sobolset(d,'Skip',skip,'Leap',leap);
                if scram p = scramble(p,'MatousekAffineOwen'); end
                points = p(1:D,1:d);
            case 'lattice'
                latticeseq_b2('initskip'); % see http://people.cs.kuleuven.be/~dirk.nuyens/qmc-generators/
                points = latticeseq_b2(d,D)';
                if scram points = mod1shift(points', rand(d,1)); points = points'; end
            case 'digit'
                load new-joe-kuo-5.21201.Cmat % see http://people.cs.kuleuven.be/~dirk.nuyens/qmc-generators/
                digitalseq_b2g('initskip', 18, new_joe_kuo_5_21201);
                points = digitalseq_b2g(d,D)';
                if scram points = digitalshift(points', rand(d,1)); points = points'; end
        end
        
        W = norminv(points', 0, 1)/sigma;
        
    case 'orf' %Orthogonal Random Features
        G = randn(D,D);
        [Q,~] = qr(G);
        
        % Chi-distributed with max(d,D) degrees of freedom
        s = sqrt(chi2rnd(D,D,1));
        % S ensures that the row norms of SQ & G are identically distributed
        S = diag(s);
        
        W = (S*Q)/sigma;
        W_orth = W(1:D,1:d);
        W = W_orth';
        
        
        
    case 'srours' %Orthogonal Random Features
        G = randn(D,D);
        [Q,~] = qr(G);
        
        % Chi-distributed with max(d,D) degrees of freedom
        s = sqrt(chi2rnd(D+2,D+2,1));
        % S ensures that the row norms of SQ & G are identically distributed
        S = diag(s(1:D));
        
        W = (S*Q)/sigma;
        W_orth = W(1:D,1:d);
        W = W_orth';
        
        
        G = randn(d,d);
        [Q,~] = qr(G);
        rho = chi2rnd(d+2,[1,1]);
        [ weights, points, ~, ~ ] = fwtpts(d, 1);
        weights(1) = 1-d/rho^2;
        weights(2:end) = 1/2/rho^2;
        points = Q*points/sqrt(3)*rho;
        
    case 'sorf' %Structured Orthogonal Random Features
        n2 = nextpow2(D);
        % Using Fast Hadamard transform, O(d log d)
        Ds = 2*(rand(2^n2,3)<0.5) - 1; % Rademacher distributed diagonals
        HD1 = sqrt(2^n2)*fwhtmy( diag(Ds(:,1)) );
        HD2 = sqrt(2^n2)*fwhtmy( diag(Ds(:,2)) );
        HD3 = sqrt(2^n2)*fwhtmy( diag(Ds(:,3)) );
        
        W = sqrt(2^n2)*HD1*HD2*HD3;
        W_SORF = W(1:D,1:d)/sigma;
        W = W_SORF';
        
        
    case 'Toep'
        n2 = nextpow2(D);
        % Using Fast Hadamard transform, O(d log d)
        Ds = 2*(rand(2^n2,3)<0.5) - 1; % Rademacher distributed diagonals
        HD3 = sqrt(2^n2)*fwhtmy( diag(Ds(:,3)) );
        x = 1:D;
        T = create_kernel(x',x','gauss',sigma);
        D2 = sign(randn(D,1));
        W1 = T*diag(D2)*HD3(1:D,1:D);
        W = W1(1:D,1:d)/sigma;
        W = sqrt(2^n2)*W';
        
    case 'rom'
        p = 3;
        d0 = d;
        c = log2(d);
        f = floor(c);
        if f~=c
            d = 2^(f+1);
        end
        W = zeros(D,d);
        t = ceil(D/d);
        for i = 1:t-1
            M = singleM(p,d);
            W((i-1)*d+1:i*d,:) = M;
        end
        i = t - 1;
        M = singleM(p,d);
        W(i*d+1:end,:) = M(1:D-i*d,:);
        W = sqrt(d)*W(1:D,1:d0);
        W = W';
        
    case 'mm'  %Moment-Matched
        G = randn(d,D);
        W = whiten(G)/sigma;
        
    case 'gq' % Gaussian Quadrature
        deg = 3; %degree of Gaussian quadrature used
        [ points, weights,~ ] = gengausshermquadrule2(deg);
        %[ points, weights] = GaussLegendre_2(deg);
        %[points, weights] = gauss_quad(deg,'he_phys');
        points = points* sqrt(2)/sigma;
        weights=weights/sqrt(pi);
        
        sz = [D,d];
        W = discretize(rand(sz),[0 cumsum(weights)]);
        for  k = min(W(:)):1:max(W(:))
            W(W == k) = points(k);
        end
        W = W';
        
    case 'gqnew' % Gaussian Quadrature
        deg = 3; %degree of Gaussian quadrature used
        [ points, weights,~ ] = gengausshermquadrule2(deg);
        %[ points, weights] = GaussLegendre_2(deg);
        %[points, weights] = gauss_quad(deg,'he_phys');
        %weights = weights/sum(weights);
        points = points* sqrt(2)/sigma;

        weights=weights/sqrt(pi);
        
        sz = [D,d];
        W = discretize(rand(sz),[0 cumsum(weights)]);
        for  k = min(W(:)):1:max(W(:))
            W(W == k) = points(k);
        end
        W = W';
        
    case 'sg'
        deg = 1;
        [points,weights]=spquad(1,deg);
        %[points,weights] = gqn (3);
        points = 2*points'*sqrt(sigma);
        weights=weights'/sqrt(pi);
        
        sz = [D,d];
        W = discretize(rand(sz),[0 cumsum(weights)]);
        for  k = min(W(:)):1:max(W(:))
            W(W == k) = points(k);
        end
        W = W';
        
    case 'fsir' %fully symmetric interpolatory rules
        
        deg = 2;
        [ weights, points, ~, ~ ] = fwtpts(1, deg);
        points = points/(sigma);
        sz = [D,d];
        W = discretize(rand(sz),[0 cumsum(weights)]);
        for  k = min(W(:)):1:max(W(:))
            W(W == k) = points(k);
        end
        W = W';
        
    case 'fsirtest' %fully symmetric interpolatory rules
        lambda = sqrt(3);
        W = zeros(d,D);
        for i = 1:D
            rand_index = randperm(d);
            draw_rand_index = rand_index(1:2);
            W(draw_rand_index(1),i) = lambda*sign(rand(1) - 0.5);
            W(draw_rand_index(2),i) = -W(draw_rand_index(1),i);
        end
        
        deg = 2;
        [ weights, points, ~, ~ ] = fwtpts(1, deg);
        points = points/(sigma);
        sz = [D,d];
        W = discretize(rand(sz),[0 cumsum(weights)]);
        for  k = min(W(:)):1:max(W(:))
            W(W == k) = points(k);
        end
        W = W';
        
    case 'fsirnew'
        deg = 1;
        [ weights, points, ~, ~ ] = fwtpts(d, deg);
        W = points;
        %points = points(:,2:end);
        %weights = weights(2:end);
        %points = points/(sigma).*repmat(weights,d,1);
        %{
        W = zeros(d,D);
        b = abs(weights); b = b/sum(b);
        %b = 1/length(b)*ones(1,length(b));
        a = randsrc(D,1,[1:size(points,2); b]);
        W = points(:,a');
        %}
    case 'sfsir' %fully symmetric interpolatory rules
        deg = 2;
        [ ~, points, ~, ~ ] = fwtpts(1, deg);
        points = points/(sigma);
        
        W2 = randn(d,D)/sigma;
        
        W3 = W2.*W2;
        wprod = sum(W3');
        a0 = abs(1-wprod/d/3);
        a1 = abs(wprod/d/6);
        aweight = [a1',a0',a1'];
        temp = sum(aweight');
        
        aweight = aweight./temp';
        
        Wt = zeros(D,d);
        for j = 1:d
            w1 = aweight(j,:);
            Wa = discretize(rand([D,1]),[0 cumsum(w1)]);
            for  k = min(Wa(:)):1:max(Wa(:))
                Wa(Wa == k) = points(k);
            end
            Wt(:,j) = Wa;
        end
        %W = Wt'/d;
        W = Wt';
        
        
    case 'cub' %fully symmetric interpolatory rules
        %deg = 2;
        %[ weights, points, ~, ~ ] = fwtpts(1, deg);
        weights = [1/3,1/3,1/3];
        points = [sqrt(3),0,sqrt(3)]';
        sz = [D,d];
        W = discretize(rand(sz),[0 cumsum(weights)]);
        for  k = min(W(:)):1:max(W(:))
            W(W == k) = points(k);
        end
        W = W';
        
        
end

