%% %% Demo of the paper "On the double descent of random features models trained with SGD" on a synthetic regression dataset

close all
clear all
%addpath('.\SRrules\')
rand('state',0);    randn('state',0);
savepath  = ['.\Results\'];

flagCV =0;
typeRF = 'rff';


lambda = 1e-8; % regularization term
NS = [10,20,30,40,50,60,80,90,120,150,200,300,400]; % the number of random features

d = 50; % feature dimension


Iternum =5; % repeat runs
epoch = 100; % the number of epochs
noise_std = 0.1; % the std of label noise


%% data generation model
n_total = 200; train_num = n_total; %training data
X_train = randn(n_total,d);
X_test = randn(n_total,d);
K_tr = create_kernel(X_train,X_train,'laplace',1/d);% generate the target function
K_te = create_kernel(X_test,X_train,'laplace',1/d);
w = randn(n_total,1);
Y_train = K_tr*w + noise_std*randn(n_total,1); %generate the label
Y_test = K_te*w + noise_std*randn(n_total,1);

res = zeros(1,length(NS)); res_e = res;
res_minnorm = res; res_minnorm_e = res;
res_diff = res;

for i = 1:length(NS)
    i
    nsample = NS(i);
    n = size(X_train,1);
    error = zeros(1,Iternum); error_minnorm = error;
    for j = 1:Iternum
        p = randperm(train_num);
        
        %% obtain random features
        D =nsample;
        b = rand(1,D)*2*pi;
        sigma = sqrt(d);
        W = RandomFeatures(D, d,sigma,typeRF);
        Z_train = createRandomFourierFeatures(D, W, b, X_train',typeRF,'rbf');
        Z_test = createRandomFourierFeatures(D, W, b, X_test',typeRF,'rbf');
       
        %% -- min norm solution %%
         w_minnorm = (Z_train * Z_train' + lambda * eye(size(Z_train,1))) \ (Z_train * (Y_train));
         y_pred = (Z_test'*w_minnorm); signal_norm = norm(w_minnorm)/(2*NS(1)); % noramlized energy of optimal solution
        error_minnorm(j) = mean((y_pred - Y_test).^2)/(norm(Y_test)^2/length(Y_test));
        %% --- average SGD--------------%%
        zetasgd = 0.5; gamma0sgd = 1e-1;
        wt1 = ones(size(Z_train,1),1)*signal_norm;
            wtotal = zeros(epoch*n,size(Z_train,1));
            mainf = zeros(epoch*n,1);
            for id = 1:epoch*n
                t = mod(id,n);
                if t == 0
                    t = n;
                end
                gammat = gamma0sgd*t^(-zetasgd);
                mainf(t) = 1/2*norm(Y_train - Z_train'*wt1)^2 + 1/2*lambda*norm(wt1)^2;
                gradf = (Z_train(:,t)'*wt1 -Y_train(t))*Z_train(:,t) + lambda*wt1;
                % - if we use so-called optimal step size
                %gammat = norm(gradf)^2 / (gradf'*(Z_train*Z_train'+ lambda * eye(size(Z_train,1)))*gradf);
                wt = wt1 - gammat* gradf;
                wtotal(id,:) = wt';
                wt1 = wt;
            end
            w = mean(wtotal); w = w';
            %norm(w - w_minnorm)
        
        %% --- prediction
        y_pred = (Z_test'*w);
        error(j) = mean((y_pred - Y_test).^2)/(norm(Y_test)^2/length(Y_test)); %normalized MSE
        
       
    end
    
    res(i) = mean(error); res_e (i) = std(error);
    res_minnorm(i) = mean(error_minnorm); res_minnorm_e (i) = std(error_minnorm);
    %res_diff(i) = norm(w-w_minnorm)/norm(w_minnorm);
   
end
figure(1), errorbar(NS/train_num,res_minnorm,res_minnorm_e,'-r');grid on;hold on;
errorbar(NS/train_num,res,res_e,'-.b');grid on;hold on;
legend('min-norm solution','average SGD');hold on;
xlabel('m/n','fontsize',18);ylabel('Test MSE','fontsize',18);grid on;

