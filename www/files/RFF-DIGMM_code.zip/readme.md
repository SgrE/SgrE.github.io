Run demo.m

The used kernel: polynomial kernel on the unit sphere
The included dataset: ijcnn1
The used classifier: liblinear
