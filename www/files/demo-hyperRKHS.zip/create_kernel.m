function K = create_kernel(x1,x2,k_type,k_par,a)

switch k_type
    case 'gauss'
        %K	= exp(-dist(x1,x2)./(k_par^2));  %%%%%
        K	= exp(-distf(x1,x2)*k_par);  %%%%%
    case 'delta-gauss'
        K	= exp(-distf(x1,x2)*k_par) - exp(-distf(x1,x2)*a); 
    case 'linear'
        K = x1*x2';
    case 'poly'
        K = (x1*x2'+1).^k_par;
    case 'log'
        K = -log(1+distf(x1,x2).^(k_par/2));
end
