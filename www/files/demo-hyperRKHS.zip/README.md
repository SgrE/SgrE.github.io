# Generalization Properties of hyper-RKHS and its Applications
*Written by Fanghui Liu, lfhsgre@gmail.com*

This repository maintains a demo of the paper [Generalization Properties of hyper-RKHS and its Applications](https://arxiv.org/abs/1809.09910).

## Run
The demo includes two main functions:   `demo_Nystrom_DC.m` and `demo_idealKernel.m`.

The main function `demo_Nystrom_DC` evaluates the kernel approximation on hyper-Gaussian kernel matrix. The main function `demo_idealKernel.m` aims to learn a kernel by KRR in hyper-RKHS and then conduct a classification task.

One can directly run the main function `demo_Nystrom_DC.m` on the `heart` dataset. More datasets can be used and then added into the path '.\dataset\'. Note that, the main function  `demo_idealKernel.m` requires the [LIBSVM](https://www.csie.ntu.edu.tw/~cjlin/libsvm/) Library.

## Ack.
Some source code(s) are from Binbin Pan et al. Out-of-sample extensions for non-parametric kernel methods. *IEEE Transactions on neural networks and learning systems*, *28*(2), pp.334-345, 2016.

