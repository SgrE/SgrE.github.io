function X_var = VarX(X)

n = size(X,1);
Xmean = mean(X,1);
XX = repmat(Xmean,[n,1]);
X_var = norm(X - XX,'fro')/sqrt(n-1);