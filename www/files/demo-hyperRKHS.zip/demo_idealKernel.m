%% This is a demo (Nystrom+DC) of the paper "Generalization Properties of hyper-RKHS and its Applications"
%% Fanghui Liu, lfhsgre@gmail.com
%% Ack. Some source code(s) are from Binbin Pan et al. "Out-of-sample extensions for non-parametric kernel methods."

close all
clear all
rand('state',0);    randn('state',0);
addpath('D:\libsvm-3.22\matlab\');% require the LIBSVM Library https://www.csie.ntu.edu.tw/~cjlin/libsvm/

%Take the heart dataset as an example
title = 'heart';
[X_train,Y_train,X_test,Y_test] = PrecessingData(title);
n=size(X_train,1); d = size(X_train,2);
Z_train = X_train;
ntest = length(Y_test);

C = 10; %SVM balance parameter, % chosen using cross validation

K = Y_train*Y_train'; % ideal kernel

Iternum =5;
res = zeros(1,Iternum);
for sss = 1:Iternum
    sss
    col_num = floor(0.01*n); % sample 1% columns
    pair = hyper_sample(n,col_num);
    vecK = hyper_vec(K,pair);  % get a vector of K according to the pair
    
    %kernel width for hyper-Gaussian kernel
    X_var = VarX(X_train);
    sigma1 = X_var;
    sigma2 = X_var;
    sigma12 = sigma1^2 + sigma2^2;
    [G, Pvec] = hyper_icf(X_train',pair,sigma1,sigma2,10^-3,1000);  % incomplete Cholesky decomposition
    
    %--------KRR in hyper-RKHS---------%
    [~,Pvec]=sort(Pvec); R=G(Pvec,:);
    Cs = [R*R';R'];
    d = [vecK;zeros(size(R,2),1)];
    lambda = 1; % chosen using cross validation
    y = (Cs'*Cs+n*lambda*eye(n))\(Cs'*d);
    %----------------------------------%
    
    k_num = length(y);
    X = [Z_train;X_test];
    
    % kernel matrix on pair data
    pairY = zeros(k_num,1);
    meanY = zeros(k_num,size(X,2));
    for k = 1:k_num
        Y = [X(pair(k,1),:);X(pair(k,2),:)];
        pairY(k) = exp(-0.25/sigma1^2*norm(Y(1,:)-Y(2,:))^2);
        meanY(k,:) = .5 * (Y(1,:) + Y(2,:));
    end
    
    % learned kernel matrix
    Ktr_learn = zeros(n,n);
    for i=1:n
        for j=1:i
            XX = [Z_train(i,:);Z_train(j,:)];
            pair1 = exp(-0.25/sigma1^2*norm(XX(1,:)-XX(2,:))^2);
            mean1 = 0.5 * (XX(1,:) + XX(2,:));
            pairX = pair1 * pairY;
            k_xy = zeros(k_num,1);
            for k=1:k_num
                pair3 = exp(-0.5/sigma12*norm(mean1-meanY(k,:))^2);
                k_xy(k) = pairX(k) * pair3;
            end
            Ktr_learn(i,j) = k_xy' * y;
            Ktr_learn(j,i) = Ktr_learn(i,j);
        end
    end
    
    % contruct kernel matrix on test data
    Kte_learn = zeros(n,ntest);
    for i=1:n
        for j=1:ntest
            %XX = [data(label_tag(i),:);data(j+train_num,:)];
            XX =  [Z_train(i,:);X_test(j,:)];
            pair1 = exp(-.25/sigma1^2*norm(XX(1,:)-XX(2,:))^2);
            mean1 = .5 * (XX(1,:) + XX(2,:));
            pairX = pair1 * pairY;
            k_xy = zeros(k_num,1);
            for k=1:k_num
                pair3 = exp(-.5/sigma12*norm(mean1-meanY(k,:))^2);
                k_xy(k) = pairX(k) * pair3;
            end
            Kte_learn(i,j) = k_xy' * y;
        end
    end
    
    %------SVM--------------%
    cmd2 = ['-q -t 4 -c ',num2str(C)];
    model = svmtrain(Y_train,[(1:n)',Ktr_learn],cmd2);
    [~,acc_hkr_train,~] = svmpredict(Y_train,[(1:n)',Ktr_learn'],model,'-q');
    [~,acc_hkr,~] = svmpredict(Y_test,[(1:ntest)',Kte_learn'],model,'-q');
    %-----------------------------------------------%
    res(sss) = acc_hkr(1);
end
fprintf('classification accuracy:  acc=%.4f��%.4f(%%)\n',mean(res),std((res)));