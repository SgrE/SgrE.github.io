function vecK = hyper_vec(K,pair);

% choose elements of K according to the pair, then form a vector

n = size(pair,1);
vecK = zeros(n,1);

for i=1:n
    vecK(i) = K(pair(i,1),pair(i,2));
end