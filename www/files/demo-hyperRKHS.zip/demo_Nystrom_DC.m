%% This is a demo (Nystrom+DC) of the paper "Generalization Properties of hyper-RKHS and its Applications"
%% Fanghui Liu, lfhsgre@gmail.com

close all
clear all
rand('state',0);    randn('state',0);

%Take the heart dataset as an example
title = 'heart';
[X_train,Y_train,X_test,Y_test] = PrecessingData(title);
n=size(X_train,1); d = size(X_train,2);
    
subset_num = 4; % the number of subsets
num_landmarks = 8;% landmarks

Iternum =10;
res = zeros(1,Iternum);res_error = res;
trtime = zeros(1,Iternum);
for sss = 1:Iternum
    
    sss
    %% subset
    subset_n = floor(n/subset_num);
    idx = randperm(n);
    X_sub = []; idx_set = [];
    for iit = 1:subset_num - 1
        X_sub{iit} = X_train(((iit-1)*subset_n +1  : (iit)*subset_n),:);
        idx_set{iit} = idx(((iit-1)*subset_n +1  : (iit)*subset_n));
    end
    X_sub{subset_num} = X_train((subset_num - 1)*subset_n +1 : end, :);
    idx_set{subset_num} = idx((subset_num - 1)*subset_n +1 : end);
    %% landmarks
    
    % all pairs
    pair = nchoosek([1:n],2);
    pair_num = size(pair,1);
    X_var = VarX(X_train);
    sigma1 = X_var;
    sigma2 = X_var;  % chosen using cross validation
    sigma12 = sigma1^2 + sigma2^2;

    K_gauss1 = create_kernel(X_train,X_train,'gauss',1/(2*sigma1^2),1);
    hyperK1 = diag(K_gauss1(pair(:,1),pair(:,2)));    
    
    K_gauss2 = create_kernel(X_train,X_train,'gauss',1/(2*sigma2^2),1);
    hyperK2 = diag(K_gauss2(pair(:,1),pair(:,2)));
    
    XX = (X_train(pair(:,1),:) + X_train(pair(:,2),:))/2;
    K_gauss3 = create_kernel(XX,XX,'gauss',1/(2*sigma12^2),1);
    
    hyperKK = K_gauss3.*(hyperK1*hyperK2'); % hyper kernel matrix on the whole data
    
    
    %% -----------submatrix--------------%
    error = zeros(1,subset_num); trainingtime = zeros(1,subset_num);
    for tt = 1:subset_num
        
        timebegin = cputime;
        
        a = idx_set{tt};
        indx = a(randperm(numel(a),num_landmarks));
        pairsub =  nchoosek(indx,2);
        pairsub_num = size(pairsub,1);
        
        hyperK1sub = diag(K_gauss1(pairsub(:,1),pairsub(:,2)));

        hyperK2sub = diag(K_gauss2(pairsub(:,1),pairsub(:,2)));
        
        XXsub = (X_train(pairsub(:,1),:) + X_train(pairsub(:,2),:))/2;
        K_gauss3 = create_kernel(XXsub,XXsub,'gauss',1/(2*sigma12^2),1);
        hyperKKsub = K_gauss3.*(hyperK1sub*hyperK2sub');
        
        %------------KZ------------------------------------%
        K_gauss3 = create_kernel(XX,XXsub,'gauss',1/(2*sigma12^2),1);
        hyperKZ = K_gauss3.*(hyperK1*hyperK2sub');
        
        [Utilde, Sigma] = eig(hyperKKsub);
        Sigma_posvec = 1./sqrt(diag(abs(Sigma)));
        
        Z_train = hyperKZ*Utilde*diag(Sigma_posvec)*Utilde';
        
        trainingtime(tt) = cputime - timebegin;
        
        error(tt) = norm(hyperKK - Z_train*Z_train','fro')/norm(hyperKK,'fro');
        
        
    end
    trtime(sss) =  mean(trainingtime);
    res_error(sss) =  mean(error);
end
fprintf('approximation error:  err=%.4f��%.4f\n',mean(res_error),std((res_error)));
fprintf('training time=%.3f��%.3f(s)\n', mean(trtime),std(trtime));