function [pair,p] = hyper_sample(n,r);

% Randomly sample r columns (r < n) to form the pair
% pair is a matrix of 0.5*(2*n-r+1)*r 

p = randperm(n);
m = 0.5*(2*n-r+1)*r;
pair = zeros(m,2);

for i=1:r
    for j=i:n
        pair( 0.5*(i-1)*(2*n-i+2) + (j-i+1), :) = [p(i),p(j)];
    end
end

p = p(1:r);