function [G, Pvec] = hyper_icf(x,pair,sigma1,sigma2,tol,iter_num);

% HYPER_ICF - incomplete Cholesky decomposition of the Gram matrix defined
%                by paired data (x1,x2), with the Gaussian hyperkernel with
%                width sigma1 and sigma2
%                x is a matrix of d x n
%                pair is a matrix of n x 2, indicating the parameter
%                (x1,x2) in hyperkernel, where x1=x(pair(1)),x2=x(pair(2))
%                Symmetric pivoting is used and the algorithms stops 
%                when the sum of the remaining pivots is less than TOL.
% 

% ICF returns an uPvecer triangular matrix G and a permutation 
% matrix P such that P'*A*P=G*G'.

% P is ONLY stored as a reordering vector PVEC such that 
%                    A(Pvec,Pvec)= G*G' 
% consequently, to find a matrix R such that A=R*R', you should do
% [a,Pvec]=sort(Pvec); R=G(Pvec,:);

% Copyright (c) Francis R. Bach, 2002.

n=size(pair,1);
if nargin < 6
    iter_num = n;
end
Pvec= 1:n;
I = [];
%calculates diagonal elements (all equal to 1 for gaussian kernels)
diagG=zeros(n,1);
for t=1:n
    diagG(t) = exp(-.25/sigma1^2*norm(x(:,pair(t,1))-x(:,pair(t,2)))^2);
end
diagA = diagG; % store the diagonal elements
diagG = diagG.^2;
diagK = diagG;
i=1;
G=[];

while ((sum(diagG(i:n))>tol)) && i<=iter_num
   G=[G zeros(n,1)];
   % find best new element
   if i>1
      [diagmax,jast]=max(diagG(i:n));
      jast=jast+i-1;
      %updates permutation
      Pvec( [i jast] ) = Pvec( [jast i] );
      % updates all elements of G due to new permutation
      G([i jast],1:i)=G([ jast i],1:i);
      % do the cholesky update
      
      
   else
      jast=1;
   end
   
   
   
   G(i,i)=diagG(jast); %A(Pvec(i),Pvec(i));
   G(i,i)=sqrt(G(i,i));
   if (i<n)    
      %calculates newAcol=A(Pvec((i+1):n),Pvec(i))
      newAcol = zeros(n-i,1);
      newAmean1 = .5 * (x(:, pair(Pvec(i),1)) + x(:, pair(Pvec(i),2)));
      newApair1 = diagA(Pvec(i));
      for t = i+1:n
        newApair2 = exp(-.25/sigma1^2*norm(x(:, pair(Pvec(t),1))-x(:, pair(Pvec(t),2)))^2);
        newAmean2 = .5 * (x(:, pair(Pvec(t),1)) + x(:, pair(Pvec(t),2)));
        newApair3 = exp(-.5/(sigma1^2+sigma2^2)*norm(newAmean1-newAmean2)^2);
        newAcol(t-i) = newApair2 * newApair3;
      end
      newAcol = newAcol * newApair1;
      
      if (i>1)
         G((i+1):n,i)=1/G(i,i)*( newAcol - G((i+1):n,1:(i-1))*(G(i,1:(i-1)))');
      else
         G((i+1):n,i)=1/G(i,i)*newAcol;
      end
      
   end
   
   % updates diagonal elements
   if (i<n) 
      diagG((i+1):n)=diagK(Pvec((i+1):n))-sum(   G((i+1):n,1:i).^2,2  );
   end
   i=i+1;
end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% function d=sqdist(a,b)
% % SQDIST - computes squared Euclidean distance matrix
% %          computes a rectangular matrix of pairwise distances
% % between points in A (given in columns) and points in B
% 
% % NB: very fast implementation taken from Roland Bunschoten
% 
% aa = sum(a.*a,1); bb = sum(b.*b,1); ab = a'*b; 
% d = abs(repmat(aa',[1 size(bb,2)]) + repmat(bb,[size(aa,2) 1]) - 2*ab);

