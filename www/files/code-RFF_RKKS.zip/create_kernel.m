function K = create_kernel(x1,x2,k_type,k_par,a)

switch k_type
    case 'delta-gauss'
        K	= exp(-distf(x1,x2)*k_par) - exp(-distf(x1,x2)*a); 
    case 'polysp'
        temp = distf(x1,x2);
        temp(temp>=4) = a^2;
        K = ( 1- temp/a^2).^k_par;
end