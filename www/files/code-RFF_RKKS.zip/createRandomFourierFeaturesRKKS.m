function Z = createRandomFourierFeaturesRKKS(D, W, W1, b, X,typeker,spos,sneg)
%creates random features


if strcmp(typeker,'delta-gauss')
    Z = sqrt(1/D)*[sqrt(spos)*cos(bsxfun(@plus,W'*X, b'));sqrt(spos)*sin(bsxfun(@plus,W'*X, b'));sqrt(sneg)*1i*cos(bsxfun(@plus,W1'*X, b'));sqrt(sneg)*1i*sin(bsxfun(@plus,W1'*X, b'))];
elseif strcmp(typeker,'polysp') | strcmp(typeker,'arccos1sp')
    %D0 = rand(D,1);
    %D0(D0<spos/(spos+sneg)) = 1;  D0(D0~=1) = -1;
    if sneg ==0
        Z = sqrt(1/D)*[cos(bsxfun(@plus,W'*X, b'));sqrt(spos)*sin(bsxfun(@plus,W'*X, b'))];
    else
        Z = sqrt(1/D)*[sqrt(spos)*cos(bsxfun(@plus,W'*X, b'));sqrt(spos)*sin(bsxfun(@plus,W'*X, b'));sqrt(sneg)*1i*cos(bsxfun(@plus,W1'*X, b'));sqrt(sneg)*1i*sin(bsxfun(@plus,W1'*X, b'))];
    end
    
    
end

end