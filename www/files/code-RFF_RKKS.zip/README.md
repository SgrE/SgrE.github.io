# README

## Introduction

1、'Faster_KRR.m' is the code of the proposed algorithm (Faster-KRR).
2、'error_estimate.m' is error estimate function, which serves 'Faster_KRR.m' function. 
3、'genKernel.m' is used for generating kernel matrix, which serves 'Faster_KRR.m' function.
4、'datasets' contains the datasets used in this paper.