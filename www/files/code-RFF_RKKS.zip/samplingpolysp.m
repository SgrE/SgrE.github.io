
function [W1,W2,spos,sneg] = samplingpolysp(D,d,p,a)
knot = D*d;
spoint = knot * 10;

%compute the integral
tt=linspace(-10,10,10000);
tau = 4;
for i = 1:2
    if i == 1%besselj
        fx1 = @(x) min(10,max(0,((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,[tau*x]) + 2*(1-4/a^2)*(2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,[tau*x])  + 2*(2/a^2)^2*(2./x).^(d/2+2).*besselj(d/2+2,[tau*x]) ) ));
        
        ff=fx1(tt);%
        spos = abs(trapz(tt,ff));
        
        
    else
        fx2 = @(x) -min(0,((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,[tau*x]) + 2*(1-4/a^2)*(2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,[tau*x])  + 2*(2/a^2)^2*(2./x).^(d/2+2).*besselj(d/2+2,[tau*x])) );
        
        ff=fx2(tt);%
        sneg = abs(trapz(tt,ff));
    end
end

fx1 = @(x) 1/spos*min(10,max(0,((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,[tau*x]) + 2*(1-4/a^2)*(2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,[tau*x])  + 2*(2/a^2)^2*(2./x).^(d/2+2).*besselj(d/2+2,[tau*x]) ) ));


if sneg ~= 0
    fx2 = @(x) -1/sneg*min(0,((1-4/a^2)^p*(2./x).^(d/2).*besselj(d/2,[tau*x]) + 2*(1-4/a^2)*(2/a^2)*(2./x).^(d/2+1).*besselj(d/2+1,[tau*x])  + 2*(2/a^2)^2*(2./x).^(d/2+2).*besselj(d/2+2,[tau*x])) );
end

if sneg == 0
    num_iter = 1;
else
    num_iter = 2;
end
for i = 1:num_iter
    aa = zeros(0); %ypro = zeros(0);
    while length(aa) < knot
        x=random('unif',-10,10,1,spoint);
        y=random('unif',0,1,1,spoint);
        if i==1
            f=fx1(x);
        else
            f = fx2(x);
        end
        
        temp = y<=f;
        b = x(temp);
        aa = [b,aa];
        
        %ypro = [ypro,y(temp)];
        if length(aa)>= knot
            break;
        end
    end
    tempa = aa(1:knot);
    
    
    W = reshape(tempa,D,d);
    
    if i == 1
        W1 = W';
    else
        W2 = W';
    end
    
    if sneg == 0
        W2 = W1;
        spos = 1;
    end
end


