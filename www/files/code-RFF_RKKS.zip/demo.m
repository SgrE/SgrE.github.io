%% Fast Learning in RKKS via Generalized Measures

% Generate some data
% Create normally distributed points and let the true classifier between
% classes be a specified radius
close all
clear all
addpath('.\CrossValidation\')
rand('state',0);    randn('state',0);

typeker = 'delta-gauss'; gamma1 = 1; gamma2 = 10; % spherical gaussian kernel
%typeker = 'polysp'; a = 2; P = 2; % spherical poly kernel; order

flagclassification = 0; flagCV =0;
if flagclassification == 1
    addpath('D:\liblinear-2.20\matlab\'); % liblinear path
end

typeC = 'liblinear';
typeCorR = 'classification';
setd = [2,4];
%setd = 1*[2,4,8,16,32];
Iternum =10;
res = zeros(length(setd),Iternum);
time_acc = zeros(length(setd),Iternum);
approxi_res = zeros(length(setd),Iternum);
for jjj = 1:length(setd)
    kkm = setd(jjj);
    n_sample = 1000;
    
    load('letter.mat')
    
    X_train = X_train./repmat(sqrt(sum(X_train.^2,2)),1,size(X_train,2));
    X_test = X_test./repmat(sqrt(sum(X_test.^2,2)),1,size(X_test,2));
    X_train(isnan(X_train)==1) = 0; X_test(isnan(X_test)==1) = 0;
    
    for sss = 1:Iternum
        
        sss
        duration = 0;
        
        
        n=size(X_train,1);
        d = size(X_train,2);
        
        D =kkm*d; % #random features
        b = zeros(1,D);
        
        tic;
        
        if strcmp(typeker,'delta-gauss')
            W1 = randn(d,D)/gamma1;
            W2 = randn(d,D)/gamma2;
            spos=1; sneg = 1;
        elseif strcmp(typeker,'polysp')
            [W1,W2,spos,sneg] = samplingpolysp(D,d,P,a);
            spos = spos/(spos+sneg); sneg = sneg/(spos+sneg);
        end
        Z_train = createRandomFourierFeaturesRKKS(D, W1,W2, b, X_train',typeker,spos,sneg);
        Z_test = createRandomFourierFeaturesRKKS(D, W1,W2, b, X_test',typeker,spos,sneg);
        
        duration = duration + toc;
        
        % ---classification---%
        if flagclassification == 1
            [accTrain, accTest] = RFclassificationRKKS(Z_train,Z_test,Y_train,Y_test,typeC,flagCV);
            res(jjj,sss) = accTest;
        end
        
        time_acc(jjj,sss) = duration;
        
        
        %% kernel approximation
        
        [temp, index] = sort(rand( length(Y_train), 1));
        X_sub = X_train(index(1:n_sample),:);
        Z_sub = Z_train(:,index(1:n_sample));
        
        if strcmp(typeker,'delta-gauss')
            K_sub = create_kernel(X_sub,X_sub,'delta-gauss',1/2/gamma1^2,1/2/gamma2^2);
        elseif strcmp(typeker,'polysp')
            K_sub = create_kernel(X_sub,X_sub,'polysp',P,a);
        end
        
        ZK = (conj(Z_sub')*Z_sub);
        
        error = norm(K_sub - ZK,'fro')/norm(K_sub,'fro');
        approxi_res(jjj,sss) = error;
        
        clear Z_train Z_test
        
    end
    clear X_train X_test Y_train Y_test
end

for j = 1:length(setd)
    kkm = setd(j);
    if flagclassification == 1
        fprintf('s = %dd: Acc=%.2f��%.2f Time=%.2f��%.2f(sec.) AppError=%.5f��%.5f\n',kkm,mean(res(j,:)),std(res(j,:)),mean(time_acc(j,:)),std(time_acc(j,:)),mean(approxi_res(j,:)),std((approxi_res(j,:))));
    else
        fprintf('s = %dd: Time=%.2f��%.2f(sec.) AppError=%.5f��%.5f\n',kkm, mean(time_acc(j,:)),std(time_acc(j,:)),mean(approxi_res(j,:)),std((approxi_res(j,:))));
    end
end
